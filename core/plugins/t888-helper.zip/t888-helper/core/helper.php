<?php

/**
 * Created by Visual Studio Code.
 * User: toanngo92
 * Date: 16/02/2024
 * Time: 10:20 AM
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

define('T888_HELPER_VERSION', '1.0.0');
define('T888_THEME_SLUG', 't888-helper');

/**
 * Register post type: register post type wordpress
 *  @return void
 * @param string $post_type
 * @param array $args
 **/

if (!function_exists('t888_reg_post_type')) {
    function t888_reg_post_type(string $post_type, array $args): void
    {
        register_post_type($post_type, $args);
    }
}

/**
 * Register taxonomy: register taxonomy wordpress
 *  @return void
 * @param string $taxonomy
 * @param string $object_type
 * @param array $args
 *
 * */

if (!function_exists('t888_reg_taxonomy')) {
    function t888_reg_taxonomy(string $taxonomy, string $object_type, string $args): void
    {
        register_taxonomy($taxonomy, $object_type, $args);
    }
}

/**
 * Register widget: register widget wordpress
 *  @return void
 * @param string|WP_Widget  $widget_class
 *
 * */

if (!function_exists('tech888f_reg_widget')) {
    function tech888f_reg_widget($widget_class)
    {
        register_widget($widget_class);
    }
}

if(!function_exists('tech888f_write_import_log')) {
    function tech888f_write_import_log($step)
    {
        $upload_dir = wp_upload_dir();
        $file_path = trailingslashit($upload_dir['basedir']) . 'import_log.txt';
        $log_message = "Importing {$step} successfully. | ";
        file_put_contents($file_path, $log_message, FILE_APPEND);
    }
}

/**
 * Get theme path: get theme path wordpress
 * @package T888 Helper
 * @since 1.0.0
 * @param string $path
 * @return string
 */

if(!function_exists('tech888f_get_theme_path')){
    function tech888f_get_theme_path($path)
    {
        $theme = wp_get_theme();
        $theme_folder = $theme->get_template();
        $theme_path = get_theme_root() . '/' . $theme_folder;

        return $theme_path . $path;
    }
}

if(!function_exists('tech888f_register_shortcodes')){
    function tech888f_register_shortcodes($tag, $func)
    {
        add_shortcode($tag, $func);
    }
}
