<?php
/*
Plugin Name:  Tech888 Helper
Plugin URI:   https://trienhkaiweb.com
Description:  Tech888 Helper is a plugin to help you install and active required plugins for Tech888 theme.
Version:      1.0.0
Author:       Toanngo92
Author URI:   https://trienhkaiweb.com
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  t888-helper
Domain Path:  /languages
*/

namespace T888Helper;

if (! defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

if (!class_exists('T888Helper')) {
    class T888Helper
    {
        // current dir and url
        static protected $_dir = '';
        static protected $_uri = '';
        private static $_instance = null;

        private function __construct()
        {
            add_action('plugins_loaded', array($this, '_load_text_domain'));

            self::$_dir = plugin_dir_path(__FILE__);
            self::$_uri = plugin_dir_url(__FILE__);

            $this->load_helper();
            $this->loadMetaBox();
            $this->loadImporter();
            $this->loadModel();
            $this->loadService();
            $this->loadController();
          
        }

        public static function getInstance()
        {
            if (self::$_instance === null) {
                self::$_instance = new self();
            }
            return self::$_instance;
        }

        public function _load_text_domain()
        {
            load_plugin_textdomain('t888-helper', false, dirname(plugin_basename(__FILE__)) . '/languages');
        }

        public function load_helper()
        {

            $array = glob(self::dir() . 'core/*');

            if (!is_array($array)) return false;

            $dirs = array_filter($array, 'is_file');

            if (!empty($dirs)) {
                foreach ($dirs as $key => $value) {
                    require_once $value;
                }
            }
        }

        public static function dir($file = false)
        {
            return self::$_dir . $file;
        }

        public static function uri($file = false)
        {
            return self::$_uri . $file;
        }

        // load all controllers
        public function loadController()
        {
            $array = glob(self::dir() . 'modules/controllers/*');

            if (!is_array($array)) return false;

            $dirs = array_filter($array, 'is_file');

            if (!empty($dirs)) {
                foreach ($dirs as $key => $value) {
                    require_once $value;
                }
            }
        }

        // load all models
        public function loadModel()
        {
            $array = glob(self::dir() . 'modules/models/*');

            if (!is_array($array)) return false;

            $dirs = array_filter($array, 'is_file');

            if (!empty($dirs)) {
                foreach ($dirs as $key => $value) {
                    require_once $value;
                }
            }
        }

        // load all services

        public function loadService()
        {
            $array = glob(self::dir() . 'modules/services/*');

            if (!is_array($array)) return false;

            $dirs = array_filter($array, 'is_file');

            if (!empty($dirs)) {
                foreach ($dirs as $key => $value) {
                    require_once $value;
                }
            }
        }

        // load metabox

        public function loadMetaBox()
        {
            if (!class_exists('MB_AIO_Loader')) {
                require_once self::dir() . 'modules/libs/meta-box-extension/index.php';
            }
        }

        public function loadImporter(){
            if (!class_exists('WP_Import')) {
                require_once self::dir() . 'modules/libs/importer/taxonomies-exporter.php';
                require_once self::dir() . 'modules/libs/importer/menu-exporter.php';
                require_once self::dir() . 'modules/libs/importer/wordpress-importer.php';
            }
        }

        // get current domain
        public static function get_domain()
        {
            $url = get_site_url();
            $parse = parse_url($url);
            return $parse['host'];
        }

        private function __clone() {}
        public function __wakeup() {}
    }
    T888Helper::getInstance();
}
