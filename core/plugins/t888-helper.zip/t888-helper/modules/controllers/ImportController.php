<?php

namespace T888Helper;

// use T888Helper\ExportImportModel;
// use T888Helper\ExportImportWidgetModel;
// use T888Helper\ExportImportOptionModel;
// use T888Helper\ExportImportSettingModel;

class Import
{
    private static $instance = null;
    private $params = [];
    private $menuService = null;
    private $settingService = null;
    private $widgetService = null;
    private $themeOptionService = null;
    private $contentService = null;
    private $sampleDataService = null;
    private $revolutionSliderService = null;
    private $elementorKitService = null;

    // Private constructor to prevent direct object creation
    private function __construct()
    {
        $this->menuService = new MenuService();
        $this->settingService = new SettingService();
        $this->widgetService = new WidgetService();
        $this->themeOptionService = new ThemeOptionService();
        $this->contentService = new ContentService();
        $this->sampleDataService = new SampleDataService();
        $this->revolutionSliderService = new RevolutionSliderService();
        $this->elementorKitService = new ElementorKitService();
        // Initialization code here
        // add new page option to admin

        add_action('admin_menu', array($this, 'add_import_page'));
        // enqueue style
        add_action('admin_enqueue_scripts', array($this, 'enqueue_assets'));

        // define ajax action only for logged in users
        // add_action('wp_ajax_start_import', array($this, 'start_import'));
        add_action('wp_ajax_start_import_step', array($this, 'start_import_step'));


        // add_action('wp_ajax_export_menus', array($this, 'export_menus'));
        add_action('wp_ajax_export_widgets', array($this, 'export_widgets'));
        add_action('wp_ajax_export_theme_options', array($this, 'export_theme_options'));
        add_action('wp_ajax_export_settings', array($this, 'export_settings'));
        add_action('wp_ajax_import_sample_data', array($this, 'import_sample_data'));
        add_action('wp_ajax_import_revolution_slider', array($this, 'import_revolution_slider'));
        add_action('wp_ajax_import_elementor_kit', array($this, 'import_elementor_kit'));
        add_action('wp_ajax_handle_post_type_change', array($this, 'handle_post_type_change'));
        $this->get_current_url_params();
    }

    public function bytes_from_shorthand($val)
    {
        if ($val === '' || $val === false) return 0;
        $val = trim($val);
        $last = strtolower(substr($val, -1));
        $num  = (float)$val;
        switch ($last) {
            case 'g':
                $num *= 1024;
            case 'm':
                $num *= 1024;
            case 'k':
                $num *= 1024;
        }
        return (int)$num;
    }

    public function format_bytes($bytes)
    {
        if (function_exists('size_format')) {
            return size_format($bytes);
        }
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        for ($i = 0; $bytes >= 1024 && $i < count($units) - 1; $i++) $bytes /= 1024;
        return round($bytes, 2) . ' ' . $units[$i];
    }


    public function get_effective_memory_limit()
    {
        $phpMem  = ini_get('memory_limit');
        $wpMem   = defined('WP_MEMORY_LIMIT') ? WP_MEMORY_LIMIT : $phpMem;
        $wpMax   = defined('WP_MAX_MEMORY_LIMIT') ? WP_MAX_MEMORY_LIMIT : $wpMem;
        $max = max($this->bytes_from_shorthand($phpMem), $this->bytes_from_shorthand($wpMem), $this->bytes_from_shorthand($wpMax));
        return $max;
    }


    public function get_system_status_data()
    {
        $uploadMax   = ini_get('upload_max_filesize');                 // e.g. "64M"
        $postMax     = ini_get('post_max_size');                       // e.g. "64M"
        $memBytes    = $this->get_effective_memory_limit();            // bytes
        $execTime    = (int)ini_get('max_execution_time');             // seconds
        $inputVars   = (int)ini_get('max_input_vars');                 // default 1000 

        $recommended = [
            'upload_max_filesize' => '64M',
            'post_max_size'       => '64M',
            'memory_limit'        => '256M',
            'max_execution_time'  => 60,
            'max_input_vars'      => 3000,
        ];

        return [
            [
                'key'         => 'upload_max_filesize',
                'label'       => __('Upload max file size', 't888-helper'),
                'current_raw' => $uploadMax,
                'current'     => $this->bytes_from_shorthand($uploadMax),
                'recommend'   => $this->bytes_from_shorthand($recommended['upload_max_filesize']),
                'display'     => $uploadMax,
                'type'        => 'bytes',
            ],
            [
                'key'         => 'memory_limit',
                'label'       => __('Memory limit', 't888-helper'),
                'current_raw' => $memBytes,
                'current'     => $memBytes,
                'recommend'   => $this->bytes_from_shorthand($recommended['memory_limit']),
                'display'     => $this->format_bytes($memBytes),
                'type'        => 'bytes',
            ],
            [
                'key'         => 'post_max_size',
                'label'       => __('Post max size', 't888-helper'),
                'current_raw' => $postMax,
                'current'     => $this->bytes_from_shorthand($postMax),
                'recommend'   => $this->bytes_from_shorthand($recommended['post_max_size']),
                'display'     => $postMax,
                'type'        => 'bytes',
            ],
            [
                'key'         => 'max_execution_time',
                'label'       => __('Max Execution Time', 't888-helper'),
                'current_raw' => $execTime,
                'current'     => $execTime,
                'recommend'   => $recommended['max_execution_time'],
                'display'     => $execTime . 's',
                'type'        => 'seconds',
            ],
            [
                'key'         => 'max_input_vars',
                'label'       => __('Max input vars', 't888-helper'),
                'current_raw' => $inputVars,
                'current'     => $inputVars,
                'recommend'   => $recommended['max_input_vars'],
                'display'     => (string)$inputVars,
                'type'        => 'number',
            ],
        ];
    }

    public function render_system_status_box()
    {
        $items = $this->get_system_status_data();
?>
        <div class="t888-box-wrap t888-box system-info-box">
            <h4 class="t888-title-heading"><?php esc_html_e("System status", "t888-helper"); ?></h4>
            <?php foreach ($items as $it):
                $ok = $it['current'] >= $it['recommend'];
                $icon = $ok ? "check.png" : "crossed.png";
                $recommendText = ($it['type'] === 'bytes')
                    ? $this->format_bytes($it['recommend'])
                    : (is_numeric($it['recommend']) ? $it['recommend'] . ($it['type'] === 'seconds' ? 's' : '') : $it['recommend']);
            ?>
                <div class="t888-iconbox">
                    <div class="t888-icon-container">
                        <img src="<?php echo get_template_directory_uri() . "/assets/images/{$icon}"; ?>"
                            alt="<?php echo esc_attr($ok ? 'OK' : 'Not OK'); ?>">
                    </div>
                    <div class="t888-iconbox-contents">
                        <span class="status-item-title">
                            <?php
                            echo esc_html($it['label'])
                                . ' (' . esc_html($it['display']) . ' / ' . esc_html($recommendText) . ')';
                            ?>
                        </span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    <?php
    }

    public function render_revolution_slider_status_box()
    {
        $is_active = $this->revolutionSliderService->isRevolutionSliderActive();
        $paths = $this->revolutionSliderService->getDirectoryPaths();

        // Create import directory if it doesn't exist
        $this->revolutionSliderService->createImportDirectory();

        $import_files = $this->revolutionSliderService->getImportFiles();

    ?>
        <div class="t888-box-wrap t888-box revolution-slider-status-box">
            <h4 class="t888-title-heading"><?php esc_html_e("Revolution Slider Status", "t888-helper"); ?></h4>

            <div class="t888-iconbox">
                <div class="t888-icon-container">
                    <img src="<?php echo get_template_directory_uri() . "/assets/images/" . ($is_active ? "check.png" : "crossed.png"); ?>"
                        alt="<?php echo esc_attr($is_active ? 'Active' : 'Inactive'); ?>">
                </div>
                <div class="t888-iconbox-contents">
                    <span class="status-item-title">
                        <?php echo esc_html($is_active ? 'Revolution Slider is active' : 'Revolution Slider is not active'); ?>
                    </span>
                    <?php if (!$is_active): ?>
                        <p><small><?php esc_html_e('Please install and activate Revolution Slider plugin to use import feature.', 't888-helper'); ?></small></p>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($is_active): ?>
                <div class="t888-iconbox">
                    <div class="t888-icon-container">
                        <img src="<?php echo get_template_directory_uri() . "/assets/images/" . (file_exists($paths['import_path']) ? "check.png" : "crossed.png"); ?>"
                            alt="<?php echo esc_attr(file_exists($paths['import_path']) ? 'Directory exists' : 'Directory missing'); ?>">
                    </div>
                    <div class="t888-iconbox-contents">
                        <span class="status-item-title">
                            Import Directory: <?php echo esc_html(file_exists($paths['import_path']) ? 'Ready' : 'Not found'); ?>
                        </span>
                        <p><small><?php echo esc_html($paths['import_path']); ?></small></p>
                    </div>
                </div>

                <div class="t888-iconbox">
                    <div class="t888-icon-container">
                        <img src="<?php echo get_template_directory_uri() . "/assets/images/" . (!empty($import_files) ? "check.png" : "crossed.png"); ?>"
                            alt="<?php echo esc_attr(!empty($import_files) ? 'Files found' : 'No files'); ?>">
                    </div>
                    <div class="t888-iconbox-contents">
                        <span class="status-item-title">
                            Import Files: <?php echo count($import_files); ?> file(s) found
                        </span>
                        <?php if (!empty($import_files)): ?>
                            <ul style="margin-top: 5px; font-size: 12px;">
                                <?php foreach ($import_files as $file): ?>
                                    <li>
                                        <?php echo esc_html($file['name']); ?>
                                        <small>(<?php echo esc_html(size_format($file['size'])); ?>)</small>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php else: ?>
                            <p><small><?php esc_html_e('Upload Revolution Slider .zip files to the import directory to use this feature.', 't888-helper'); ?></small></p>
                        <?php endif; ?>
                    </div>
                </div>

            <?php endif; ?>
        </div>
<?php
    }

    // Method to enqueue styles
    public function enqueue_assets($hook_suffix)
    {
        if (in_array($hook_suffix, [
            'appearance_page_import-page',
            'appearance_page_export-menu',
            'appearance_page_export-settings',
            'appearance_page_export-widgets',
            'appearance_page_export-theme-options',
            'appearance_page_import-sample-data',
        ])) {
            wp_enqueue_style('import-page-style', T888Helper::uri('/assets/css/import-page.css'), '1.0.0');
            wp_enqueue_script('import-page-script', T888Helper::uri('/assets/js/import-page.js'), ['jquery'], '1.0.0', true);
            wp_localize_script('import-page-script', 'import_page', [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce'    => wp_create_nonce('import_nonce'),
                'upload_url' => wp_upload_dir()['baseurl'] . '/',
            ]);
        }
    }


    public function get_current_url_params()
    {
        $scheme = $_SERVER['REQUEST_SCHEME'] ?? (
            (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http'
        );

        $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
        $uri  = $_SERVER['REQUEST_URI'] ?? '/';

        $current_url = $scheme . '://' . $host . $uri;

        $url_components = parse_url($current_url);
        // fix warning ajax request
        if (!isset($url_components['query'])) return;
        parse_str($url_components['query'], $params);
        $this->params = $params;
    }

    // Method to add the import page to the admin menu
    public function add_import_page()
    {
        add_submenu_page(
            'themes.php', // Parent slug
            __('Import Demos', 't888-helper'), // Page title
            __('Import Demos', 't888-helper'), // Menu title
            'manage_options', // Capability
            'import-page', // Menu slug
            array($this, 'render') // Callback function
        );

        // Check if debug mode is enabled
        if (defined('WP_DEBUG') && WP_DEBUG) {
            // add_submenu_page(
            //     'themes.php', // Parent slug
            //     __('Export Menu Location', 't888-helper'), // Page title
            //     __('Export Menu Location', 't888-helper'), // Menu title
            //     'manage_options', // Capability
            //     'export-menu', // Menu slug
            //     array($this, 'render_export_menu') // Callback function
            // );
            add_submenu_page(
                'themes.php', // Parent slug
                __('Export Settings', 't888-helper'), // Page title
                __('Export Settings', 't888-helper'), // Menu title
                'manage_options', // Capability
                'export-settings', // Menu slug
                array($this, 'render_export_settings') // Callback function
            );
            add_submenu_page(
                'themes.php', // Parent slug
                __('Export Widgets', 't888-helper'), // Page title
                __('Export Widgets', 't888-helper'), // Menu title
                'manage_options', // Capability
                'export-widgets', // Menu slug
                array($this, 'render_export_widgets') // Callback function
            );
            add_submenu_page(
                'themes.php', // Parent slug
                __('Export Theme Options', 't888-helper'), // Page title
                __('Export Theme Options', 't888-helper'), // Menu title
                'manage_options', // Capability
                'export-theme-options', // Menu slug
                array($this, 'render_export_theme_options') // Callback function
            );
            add_submenu_page(
                'themes.php', // Parent slug
                __('Import Sample Data', 't888-helper'), // Page title
                __('Import Sample Data', 't888-helper'), // Menu title
                'manage_options', // Capability
                'import-sample-data', // Menu slug
                [$this, 'render_import_sample_data_page'] // Callback function
            );
        }
    }


    public function export_menus()
    {
        $menu_id = sanitize_text_field($_POST['menu']);
        $response = array();
        if ($menu_id === 'all') {
            $menus = $this->menuService->menuModel->getListMenus();
            foreach ($menus as $menu) {
                $response = $this->menuService->export_menu($menu->term_id);
                if ($response['success'] === false) {
                    break;
                }
            }
        } else {
            $response = $this->menuService->export_menu($menu_id);
        }

        wp_send_json($response);
    }


    public function export_widgets()
    {
        $sidebar_widgets = sanitize_text_field($_POST['sidebar_widgets']);
        $res = $this->widgetService->saveSidebarWidgets($sidebar_widgets);
        wp_send_json($res);
    }

    public function export_theme_options()
    {
        $theme_options = sanitize_text_field($_POST['theme_options']);
        $res = $this->themeOptionService->saveThemeOptions($theme_options);

        wp_send_json($res);
    }
    public function export_settings()
    {
        $show_on_front = sanitize_text_field($_POST['show_on_front']);
        $page_on_front = sanitize_text_field($_POST['page_on_front']);
        $page_for_posts = sanitize_text_field($_POST['page_for_posts']);
        $date_format = sanitize_text_field($_POST['date_format']);
        $time_format = sanitize_text_field($_POST['time_format']);
        $posts_per_page = sanitize_text_field($_POST['posts_per_page']);
        $permalink_structure = sanitize_text_field($_POST['permalink_structure']);
        $woocommerce_shop_page = sanitize_text_field($_POST['woocommerce_shop_page']);
        $woocommerce_cart_page = sanitize_text_field($_POST['woocommerce_cart_page']);
        $woocommerce_checkout_page = sanitize_text_field($_POST['woocommerce_checkout_page']);
        $woocommerce_myaccount_page = sanitize_text_field($_POST['woocommerce_myaccount_page']);
        $elementor_css_print_method = sanitize_text_field($_POST['elementor_css_print_method']);
        $elementor_cpt_support = $_POST['elementor_cpt_support'] ?? array();
        $elementor_cpt_support = array_map('sanitize_text_field', $elementor_cpt_support);
        $elementor_cpt_support = array_unique($elementor_cpt_support);
        $data = array(
            'show_on_front' => $show_on_front,
            'page_on_front' => $page_on_front,
            'page_for_posts' => $page_for_posts,
            'date_format' => $date_format,
            'time_format' => $time_format,
            'posts_per_page' => $posts_per_page,
            'permalink_structure' => $permalink_structure,
            'woocommerce_shop_page' => $woocommerce_shop_page,
            'woocommerce_cart_page' => $woocommerce_cart_page,
            'woocommerce_checkout_page' => $woocommerce_checkout_page,
            'woocommerce_myaccount_page' => $woocommerce_myaccount_page,
            'elementor_css_print_method' => $elementor_css_print_method,
            'elementor_cpt_support' => $elementor_cpt_support
        );
        $res = $this->settingService->saveSettings($data);
        wp_send_json($res);
    }

    public function import_revolution_slider()
    {
        check_ajax_referer('import_nonce', 'nonce');

        $file_path = isset($_POST['file_path']) ? sanitize_text_field($_POST['file_path']) : null;
        $update_existing = isset($_POST['update_existing']) ? (bool)$_POST['update_existing'] : true;

        $response = $this->revolutionSliderService->importRevolutionSlider($file_path, $update_existing);

        if ($response['success']) {
            tech888f_write_import_log('revolution_slider');
        }

        wp_send_json($response);
    }

    public function import_elementor_kit()
    {
        check_ajax_referer('import_nonce', 'nonce');

        $file_path = isset($_POST['file_path']) ? sanitize_text_field($_POST['file_path']) : null;
        $update_existing = isset($_POST['update_existing']) ? (bool)$_POST['update_existing'] : true;

        $response = $this->elementorKitService->importElementorKit($file_path, $update_existing);

        if ($response['success']) {
            tech888f_write_import_log('elementor_kit');
        }

        wp_send_json($response);
    }


    public function render_export_menu()
    {
        // load view
        $data = [
            'menuModel' => $this->menuService->menuModel,
        ];
        ModuleController::load_view('export-menu/form-export-menu', $data);
    }

    public function render_export_widgets()
    {
        $data = array();
        ModuleController::load_view('export-widgets/form-export-widgets', $data);
    }

    public function render_export_theme_options()
    {
        $theme_options = $this->themeOptionService->getThemeOptions();
        $data = array(
            'theme_options' => $theme_options,
        );
        ModuleController::load_view('export-theme-options/form-export-theme-options', $data);
    }
    public function render_export_settings()
    {
        $data = [
            'settingModel' => new ExportImportSettingModel()
        ];
        ModuleController::load_view('export-settings/form-export-settings', $data);
    }
    public function render_menu()
    {
        ModuleController::load_view('common-menu', array());
    }

    public function render_import_page()
    {
        ModuleController::load_view('import-page/import-page', array());
    }

    public function render_import_process()
    {
        ModuleController::load_view('import-page/import-process', array());
    }

    public function render_import_sample_data_page()
    {
        ModuleController::load_view('import-sample-data/import-sample-data', array());
    }

    public function check_is_view_import(){
        return isset($this->params['page']) && $this->params['page'] === 'import-page' && (isset($this->params['view']) && $this->params['view'] === 'import');
    }

    public function check_is_view_import_process(){
        return isset($this->params['page']) && $this->params['page'] === 'import-page' && (isset($this->params['view']) && $this->params['view'] === 'import_process');
    }

    public function render()
    {
       
        $this->render_menu();
         if ($this->check_is_view_import() || $this->check_is_view_import_process()) {
            if (!VerifyPurchaseController::_check_verify()) {
                echo '<div class="container">';
                echo '<div class="vr-message message-error">'.esc_html__('You must verify your purchase to access this page.', 't888-helper').'</div>';
                echo '</div>';
                return;
            }
        }
        if (isset($this->params['view'])) :
            switch ($this->params['view']) {
                case 'import':
                    $this->render_import_page();
                    break;
                case 'import_process':
                    $this->render_import_process();
                    break;
                default:
                case 'dashboard':
                    $this->render_dashboard();
                    break;
            }
        else:
            $this->render_dashboard();
        endif;
    }

    public function render_dashboard()
    {
        // load view
        ModuleController::load_view('dashboard', ['import' => $this]);
    }
    private function bump_limits()
    {
        if (function_exists('wp_raise_memory_limit')) {
            wp_raise_memory_limit('admin');
        }
        @set_time_limit(0);
        @ini_set('max_execution_time', '0');
    }

    /** deprecated */
    public function start_import()
    {
        check_ajax_referer('import_nonce', 'nonce');
        // $data = sanitize_text_field($_POST['select_data']);
        $data = array(
            'import_media' => isset($_POST['import_media']) ? 1 : 0,
            'import_content' => isset($_POST['import_content']) ? 1 : 0,
            'import_theme_options' => isset($_POST['import_theme_options']) ? 1 : 0,
            'import_widgets' => isset($_POST['import_widgets']) ? 1 : 0,
            'import_settings' => isset($_POST['import_settings']) ? 1 : 0,
            'import_menus' => isset($_POST['import_menus']) ? 1 : 0,
            'import_media_option' => isset($_POST['import_media_option']) ? sanitize_text_field($_POST['import_media_option']) : 'local',
        );

        // 1. import content

        $importcontentsuccess = false;
        if ($data['import_content']) {
            $fetch_attachments = $data['import_media_option'] === 'fetch' ? true : false;
            $importcontentsuccess = $this->contentService->importContent($fetch_attachments);
        }

        if ($importcontentsuccess) {
            //write to file import_log.txt in uploads folder
            tech888f_write_import_log('content');
        }

        // 2. import menu
        $importmenusuccess = false;
        if ($data['import_menus']) {
            $importmenusuccess = $this->menuService->importMenus();
        }

        // 3. import settings

        $importsettingsuccess = false;

        if ($data['import_settings']) {
            $importsettingsuccess = $this->settingService->importSettings();
        }

        // write to log file step by step

        if ($importsettingsuccess) {
            //write to file import_log.txt in uploads folder
            tech888f_write_import_log('settings');
        }

        // 4. import widgets

        $importwidgetssuccess = false;

        if ($data['import_widgets']) {
            $importwidgetssuccess = $this->widgetService->importWidgets();
        }

        // write to log file step by step
        if ($importwidgetssuccess) {
            //write to file import_log.txt in uploads folder
            tech888f_write_import_log('widgets');
        }

        // 5. import theme options
        $importthemeoptionssuccess = false;
        if ($data['import_theme_options']) {
            $importthemeoptionssuccess = $this->themeOptionService->importThemeOptions();
        }
        if ($importthemeoptionssuccess) {
            tech888f_write_import_log('theme_options');
        }


        // 6. import media  

        $importmediasuccess = false;

        if ($data['import_media']) {
            if ($data['import_media_option'] === 'local') {
                $importmediasuccess = true;
                // do not use this option
                // $importmediasuccess = $this->contentService->importMedia();
            }
        }

        if ($importmediasuccess) {
            //write to file import_log.txt in uploads folder
            tech888f_write_import_log('media');
        }

        $response = array(
            'success' => true,
            'message' => 'All done !',
            'data' => $data,
        );
        wp_send_json($response);
    }

    /**
     * Start import step
     */
    public function start_import_step()
    {
        check_ajax_referer('import_nonce', 'nonce');

        $step = isset($_POST['step']) ? sanitize_text_field($_POST['step']) : '';
        if (!$step) {
            wp_send_json_error(['message' => 'Missing step']);
        }

        // get options from post data
        $opts = [
            'import_media'         => !empty($_POST['import_media']),
            'import_content'       => !empty($_POST['import_content']),
            'import_theme_options' => !empty($_POST['import_theme_options']),
            'import_widgets'       => !empty($_POST['import_widgets']),
            'import_settings'      => !empty($_POST['import_settings']),
            'import_menus'         => !empty($_POST['import_menus']),
            'assign_menus_to_locations' => !empty($_POST['assign_menus_to_locations']),
            'import_revolution_slider' => !empty($_POST['import_revolution_slider']),
            'import_media_option'  => isset($_POST['import_media_option']) ? sanitize_text_field($_POST['import_media_option']) : 'local',
            'import_elementor_kit' => !empty($_POST['import_elementor_kit']),
        ];

        // $this->bump_limits(); // bật nếu cần

        $ok = false;
        $label = '';
        $msg = '';

        switch ($step) {


            case 'menus':
                $label = __('Menus', 't888-helper');

                if (!$opts['import_menus']) {
                    $ok = true;
                    break;
                }

                try {
                    $result = $this->menuService->importMenus();

                    if (is_wp_error($result)) {
                        $ok  = false;
                        $msg = $result->get_error_message(); // <-- hiện đúng message
                    } else {
                        $ok  = (bool) $result;
                        if (!$ok) {
                            $msg = __('Menu import returned false. Turn on WP_DEBUG_LOG to see details.', 't888-helper');
                        }
                    }
                } catch (\Throwable $e) {
                    $ok  = false;
                    $msg = $e->getMessage();
                    if (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) {
                        error_log('[Menus import] ' . $e->getMessage());
                    }
                }

                if ($ok) {
                    tech888f_write_import_log('menus');
                }
                break;
            case 'assign_menus_to_locations':
                $label = __('Assign Menus to Locations', 't888-helper');

                if (!$opts['assign_menus_to_locations']) {
                    $ok = true;
                    break;
                }

                try {
                    $result = $this->menuService->assignMenusToLocations();

                    if (is_wp_error($result)) {
                        $ok  = false;
                        $msg = $result->get_error_message(); // <-- hiện đúng message
                    } else {
                        $ok  = (bool) $result;
                        if (!$ok) {
                            $msg = __('Assigning menus to locations returned false. Turn on WP_DEBUG_LOG to see details.', 't888-helper');
                        }
                    }
                } catch (\Throwable $e) {
                    $ok  = false;
                    $msg = $e->getMessage();
                    if (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) {
                        error_log('[Assign Menus to Locations] ' . $e->getMessage());
                    }
                }
                if ($ok) {
                    tech888f_write_import_log('assign_menus_to_locations');
                }
                break;

            case 'settings':
                $label = __('Settings', 't888-helper');
                $ok = $opts['import_settings'] ? $this->settingService->importSettings() : true;
                if ($ok && $opts['import_settings']) tech888f_write_import_log('settings');
                break;

            case 'widgets':
                $label = __('Widgets', 't888-helper');
                $ok = $opts['import_widgets'] ? $this->widgetService->importWidgets() : true;
                if ($ok && $opts['import_widgets']) tech888f_write_import_log('widgets');
                break;

            case 'theme_options':
                $label = __('Theme Options', 't888-helper');
                $ok = $opts['import_theme_options'] ? $this->themeOptionService->importThemeOptions() : true;
                if ($ok && $opts['import_theme_options']) tech888f_write_import_log('theme_options');
                break;

            case 'media':
                $label = __('Media', 't888-helper');

                if ($opts['import_media']) {
                    if ($opts['import_media_option'] === 'local') {
                        // $res = $this->contentService->importMedia();

                        // if (is_wp_error($res)) {
                        //     $ok  = false;
                        //     $msg = $res->get_error_message(); // hiện đúng lỗi
                        // } else {
                        //     $ok = (bool) $res;
                        //     if (!$ok) {
                        //         $msg = __('Unzip returned false. Turn on WP_DEBUG_LOG to see details.', 't888-helper');
                        //     }
                        // }
                        $ok = true;
                        $msg = __('Media import from local skipped. Please use "Fetch external images" option in Content step to get media.', 't888-helper');

                        if ($ok) tech888f_write_import_log('media');
                    } else {
                        // Đã fetch ảnh ngay trong bước content
                        $ok  = true;
                        $msg = __('Media fetched with content step.', 't888-helper');
                    }
                } else {
                    $ok = true;
                    if ($ok) {
                        $sum = $this->contentService->assignThumbnailsAuto(['post', 'product'], true);
                        $msg .= sprintf(
                            ' Assigned thumbnails: %d, gallery items: %d.',
                            (int)$sum['assigned'],
                            (int)$sum['gallery_added']
                        );
                    }
                }
                break;

            case 'revolution_slider':
                $label = 'Revolution Slider';

                if ($opts['import_revolution_slider']) {
                    try {
                        $result = $this->revolutionSliderService->importRevolutionSlider();

                        if (is_wp_error($result)) {
                            $ok  = false;
                            $msg = $result->get_error_message();
                        } elseif (is_array($result) && isset($result['success'])) {
                            $ok  = $result['success'];
                            $msg = $result['message'];
                        } else {
                            $ok  = (bool) $result;
                            if (!$ok) {
                                $msg = 'Revolution Slider import failed. Check if files exist in import directory.';
                            }
                        }

                        if ($ok) {
                            tech888f_write_import_log('revolution_slider');
                        }
                    } catch (\Exception $e) {
                        $ok  = false;
                        $msg = $e->getMessage();
                        if (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) {
                            error_log('[Revolution Slider import] ' . $e->getMessage());
                        }
                    }
                } else {
                    $ok = true;
                    $msg = 'Revolution Slider import skipped.';
                }
                break;
            case 'content':
                $label = __('Content', 't888-helper');
                $ok = $opts['import_content']
                    ? $this->contentService->importContent($opts['import_media_option'] === 'fetch')
                    : true;
                if ($ok && $opts['import_content']) tech888f_write_import_log('content');
                break;
            case 'elementor_kit':
                $label = esc_html__('Elementor Kit', 't888-helper');
                $ok = $opts['import_elementor_kit']
                    ? $this->elementorKitService->importElementorKit()
                    : true;
                if ($ok && $opts['import_elementor_kit']) tech888f_write_import_log('elementor_kit');
                break;
            default:
                wp_send_json_error(['message' => 'Unknown step: ' . $step]);
        }

        $payload = [
            'step'    => $step,
            'label'   => $label,
            'message' => $msg ?: sprintf(__('%s imported.', 't888-helper'), $label),
        ];
        $ok ? wp_send_json_success($payload) : wp_send_json_error($payload);
    }

    public function import_sample_data()
    {
        check_ajax_referer('import_nonce', 'nonce');
        // validate and sanitize input data
        $action_type = sanitize_text_field($_POST['action_type'] ?? '');
        $post_type = sanitize_text_field($_POST['post_type']);
        $excerpts = isset($_POST['excerpt']) ? array_map('wp_kses_post', $_POST['excerpt']) : array();
        $contents = isset($_POST['content']) ? array_map('wp_kses_post', $_POST['content']) : array();
        $titles = isset($_POST['titles']) ? array_map('sanitize_text_field', $_POST['titles']) : array();
        $cats = isset($_POST['cats']) ? array_map('intval', $_POST['cats']) : array();
        $post_count = intval($_POST['post_count']);
        $field_type_update = isset($_POST['field_type']) ? sanitize_text_field($_POST['field_type']) : '';
        $thumbnails_update = isset($_POST['thumbnails_value']) ? explode(',', sanitize_text_field($_POST['thumbnails_value'])) : array();
        $thumbs_hover_update = isset($_POST['thumbs_hover_value']) ? explode(',', sanitize_text_field($_POST['thumbs_hover_value'])) : array();
        $galleries = isset($_POST['gallery_value']) ? explode(',', sanitize_text_field($_POST['gallery_value'])) : array();
        $cats_update = isset($_POST['cats_value']) ? explode(',', sanitize_text_field($_POST['cats_value'])) : array();
        $tags_update = isset($_POST['tags_value']) ? explode(',', sanitize_text_field($_POST['tags_value'])) : array();
        $excerpt_update = isset($_POST['excerpt_value']) ?  wp_kses_post($_POST['excerpt_value']) : '';
        $content_update = isset($_POST['content_value']) ?  wp_kses_post($_POST['content_value']) : '';
        $title_update = isset($_POST['title_value']) ? sanitize_text_field($_POST['title_value']) : '';
        $post_ids_exclude = isset($_POST['post_ids_exclude']) ? array_map('intval', explode(',', sanitize_text_field($_POST['post_ids_exclude']))) : array();


        $response = $this->sampleDataService->importSampleData(
            $action_type,
            $post_type,
            $excerpts,
            $contents,
            $post_count,
            $titles,
            $cats,
            $field_type_update,
            $thumbnails_update,
            $thumbs_hover_update,
            $galleries,
            $cats_update,
            $tags_update,
            $excerpt_update,
            $content_update,
            $title_update,
            $post_ids_exclude
        );

        if ($response['success']) {
            tech888f_write_import_log('sample_data');
        }

        wp_send_json($response);
    }

    public function handle_post_type_change()
    {
        check_ajax_referer('import_nonce', 'nonce');
        $post_type = sanitize_text_field($_POST['post_type']);
        switch ($post_type) {
            case 'post':
                $categories = get_categories(array('hide_empty' => false));
                $response = array(
                    'success' => true,
                    'message' => __('Post type changed successfully.', 't888-helper'),
                    'categories' => $categories,
                );
                break;
            case 'product':
                $categories = get_terms(array(
                    'taxonomy' => 'product_cat',
                    'hide_empty' => false,
                ));
                $response = array(
                    'success' => true,
                    'message' => __('Post type changed successfully.', 't888-helper'),
                    'categories' => $categories,
                );
                break;
            default:
            case 'page':
                $response = array('success' => false, 'message' => __('Do not support this post type.', 't888-helper'));
                break;
        }
        wp_send_json($response);
    }

    // Method to get the singleton instance
    public static function getInstance()
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    // Prevent cloning of the instance
    private function __clone() {}

    // Prevent unserializing of the instance
    public function __wakeup() {}
}

// Get the singleton instance of the Import class
$import = Import::getInstance();
