<?php

namespace T888Helper;

class VerifyPurchaseController extends ModuleController
{
    private static $instance = null;

    private function __construct()
    {
        // add_action('admin_menu', array(__CLASS__, '_add_sub_menu_notify'));
        // check if is page have parameter theme_verify
        if (isset($_GET['page']) && $_GET['page'] === 'theme_verify' && is_admin() && !wp_doing_ajax()) {
            add_action('admin_enqueue_scripts', array(__CLASS__, '_add_verify_scripts'));
        }
        // ajax verify purchase code 
        add_action('wp_ajax_purchase_code_verify', array(__CLASS__, '_purchase_code_verify'));
        add_action('wp_ajax_nopriv_purchase_code_verify', array(__CLASS__, '_purchase_code_verify'));
    }

    public static function getInstance()
    {
        if (self::$instance == null) {
            self::$instance = new VerifyPurchaseController();
        }
        return self::$instance;
    }

    public static function _add_sub_menu_notify()
    {
        $check = '';
        if (function_exists('get_option')) $check = get_option('disable_verify_notice');
        // define function callback in submenupage
        $_load_view = function () {
            $view = 'verify/verify'; // 'verify/verify' is the default view
            self::load_view($view);
        };
        if ($check != 'on') add_menu_page(esc_html__('Activate Theme', 't888-helper'), esc_html__('Activate Theme', 't888-helper'), 'manage_options', 'theme_verify', $_load_view, 'dashicons-admin-network', 25);
    }

    public static function _check_verify($code_to_verify = '', $envato_name = '')
    {
        if (empty($code_to_verify)) $code_to_verify = get_option('user_purchase_code');
        if (empty($envato_name)) $envato_name = get_option('user_envato_name');
        $code_to_verify = trim($code_to_verify);
        $envato_name = trim($envato_name);
        if ($envato_name == '7uptheme') {
            if (strlen($code_to_verify) >= 12 && strpos($code_to_verify, '7upcoder-') == 0) {
                return true;
            }
        }
        $data = self::_get_verify_data($code_to_verify);
        if (is_array($data)) {
            if (isset($data['buyer']) && $data['buyer'] == $envato_name && $data['domain'] == T888Helper::get_domain()) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public static function _get_verify_data($code_to_verify = '')
    {
        $data = get_option('user_verify_data');
        if ($data == '' || empty($data)) {
            // Open cURL channel
            $ch = wp_remote_get("https://7uptheme.net/verifycode.json?verify=" . $code_to_verify);

            // Decode returned JSON
            if (is_array($ch) && isset($ch['body'])) {
                $data_body = json_decode($ch['body'], true);
                if (isset($data_body['buyer'])) {
                    $data = array();
                    $data['item_name'] = $data_body['item']['name'];
                    $data['item_id'] = $data_body['item']['id'];
                    $data['created_at'] = $data_body['sold_at'];
                    $data['buyer'] = $data_body['buyer'];
                    $data['licence'] = $data_body['license'];
                    $data['supported_until'] = $data_body['supported_until'];
                    $data['domain'] = $data_body['domain'];
                    $output['verify-purchase'] = $data;
                } else $data = '';
            } else $data = '';
        } else {
            $output['verify-purchase'] = $data;
        }

        if (isset($output['verify-purchase'])) {
            $output = $output['verify-purchase'];
            return $output;
        }

        return false;
    }

    public static function _purchase_code_verify()
    {
        $theme = wp_get_theme();
        $envato_name = $_POST['envato_name'];
        $code_to_verify = $_POST['user_purchase_code'];
        update_option('user_envato_name', $envato_name);
        update_option('user_purchase_code', $code_to_verify);
        if (self::_check_verify($code_to_verify, $envato_name)) {
            echo '<div class="vr-message message-success">' . esc_html__('Successful activation!', 't888-helper') . '</div>';
            $data = self::_get_verify_data($code_to_verify);
            update_option('user_verify_data', $data);
            $data['theme'] =  $theme;
            if (isset($data['buyer'])) {
                // self::load_view(('verify/ajax/success'), $data);
            }
        } else {
            update_option('user_verify_data', '');
            echo '<p class="vr-message message-error">' . esc_html__('Your Invalid information!. Please recheck envato username or purchase code', 't888-helper') . '</p>';
        }
        die();
    }

    public static function _add_verify_scripts()
    {
        $assets_url = T888Helper::uri('assets');
        wp_enqueue_script('theme-verify-js', $assets_url . '/js/verify.js', array('jquery'), null, true);
    }
}

VerifyPurchaseController::getInstance();
