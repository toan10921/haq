<?php
namespace T888Helper;
class ModuleController{

    public function __construct(){
   
    }
    
    // load view
    public static function load_view($view,$data = array()){
        $file = T888Helper::dir('modules/views/'.$view.'.php');
        if(file_exists($file)){
            extract($data);
            include $file;
        }
    }
}