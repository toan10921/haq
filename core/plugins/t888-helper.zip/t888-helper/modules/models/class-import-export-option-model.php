<?php
namespace T888Helper;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

if (!class_exists('ExportImportOptionModel')) :

class ExportImportOptionModel
{
    public function __construct()
    {
        // Reserved for future initializations if needed
    }

    /**
     * Export selected WordPress options into a JSON string.
     *
     * @param array $option_names List of option names to export.
     * @return string|false JSON string if successful, false otherwise.
     */
    public function generateOptionsJson(array $option_names = [])
    {
        global $wpdb;
    
        if (empty($option_names)) {
            $results = $wpdb->get_results("SELECT option_name FROM $wpdb->options WHERE option_name LIKE 'theme_mods_%'", ARRAY_A);
            foreach ($results as $row) {
                $option_names[] = $row['option_name'];
            }
        }
    
        $export_data = [];
    
        foreach ($option_names as $option_name) {
            $option_value = get_option($option_name, null);
            if (!is_null($option_value)) {
                $export_data[$option_name] = $option_value;
            }
        }
    
        return json_encode($export_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }
    
 
    /**
     * Import options from a JSON string.
     *
     * @param string $json_data JSON string containing options data.
     * @return bool True if import was successful, false otherwise.
     */
    public function importOptionsJson($json_data)
    {
        $data = json_decode($json_data, true);

        if (!is_array($data)) {
            return false;
        }

        foreach ($data as $option_name => $option_value) {
            update_option($option_name, $option_value);
        }

        return true;
    }
}

endif;
?>
