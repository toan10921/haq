<?php
namespace T888Helper;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

if (!class_exists('ExportImportWidgetModel')) :

class ExportImportWidgetModel
{
    public function __construct()
    {
        // Reserved for future use
    }

    /**
     * Export widget data and sidebars_widgets option to JSON.
     *
     * @return string|false JSON string if successful, false otherwise.
     */

    public function generateWidgetsJson($widget_class = 'all')
    {
        $data = [];
    
        $sidebars = get_option('sidebars_widgets');
    
        global $wpdb;
        $widget_options = $wpdb->get_results("SELECT option_name, option_value FROM $wpdb->options WHERE option_name LIKE 'widget_%'", ARRAY_A);
    
        $widgets = [];
        foreach ($widget_options as $opt) {
            if ($widget_class === 'all' || strpos($opt['option_name'], $widget_class) !== false) {
                $widgets[$opt['option_name']] = maybe_unserialize($opt['option_value']);
            }
        }
    
        $data['sidebars'] = $sidebars;
        $data['widgets'] = $widgets;
    
        return json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }

    /**
     * Import widgets and sidebars from JSON data.
     *
     * @param string $json_data JSON string containing sidebar and widget data.
     * @return bool True if import was successful, false otherwise.
     */
    public function importWidgetsJson($json_data)
    {
        $data = json_decode($json_data, true);

        if (!is_array($data) || empty($data['sidebars_widgets']) || empty($data['widget_instances'])) {
            return false;
        }

        // Restore sidebars
        update_option('sidebars_widgets', $data['sidebars_widgets']);

        // Restore each widget instance
        foreach ($data['widget_instances'] as $option_name => $instances) {
            update_option($option_name, $instances);
        }

        return true;
    }
}

endif;
?>
