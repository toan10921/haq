<?php
namespace T888Helper;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

if (!class_exists('ExportImportSettingModel')) :

class ExportImportSettingModel
{
    public function __construct()
    {
        // Reserved for future initializations if needed
    }

    /**
     * Export all site settings (autoload options) to JSON.
     *
     * @return string JSON string of settings
     */
    public function generateSettingsJson()
    {
        global $wpdb;

        $results = $wpdb->get_results(
            "SELECT option_name, option_value FROM {$wpdb->options} WHERE autoload = 'yes'", 
            ARRAY_A
        );

        $settings = [];
        foreach ($results as $row) {
            $settings[$row['option_name']] = maybe_unserialize($row['option_value']);
        }

        return json_encode($settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }
}

endif;
?>
