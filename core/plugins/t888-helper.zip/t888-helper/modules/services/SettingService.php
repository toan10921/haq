<?php

namespace T888Helper;

class SettingService
{
    public function __construct() {}

    public function getSettings()
    {
        $show_on_front = get_option('show_on_front', 'posts');
        $home_page = get_option('page_on_front');
        // get home page slug
        $home_page_slug = get_post($home_page)->post_name ?? '';
        // get page for posts slug
        $page_for_posts = get_option('page_for_posts');
        // get page for posts slug
        $page_for_posts_slug = get_post($page_for_posts)->post_name ?? '';
        // get woocommerce shop page
        $woocommerce_shop_page_id = get_option('woocommerce_shop_page_id');
        // get shop page slug
        $woocommerce_shop_page_slug = get_post($woocommerce_shop_page_id)->post_name ?? '';
        // get woocommerce cart page
        $woocommerce_cart_page_id = get_option('woocommerce_cart_page_id');
        // get cart page slug
        $woocommerce_cart_page_slug = get_post($woocommerce_cart_page_id)->post_name ?? '';
        // get woocommerce checkout page
        $woocommerce_checkout_page_id = get_option('woocommerce_checkout_page_id');
        // get checkout page slug
        $woocommerce_checkout_page_slug = get_post($woocommerce_checkout_page_id)->post_name ?? '';

        // get woocommerce my account page
        $woocommerce_myaccount_page_id = get_option('woocommerce_myaccount_page_id');
        // get my account page slug
        $woocommerce_myaccount_page_slug = get_post($woocommerce_myaccount_page_id)->post_name ?? '';

        // get Elementor CSS print method

        $elementor_css_print_method = get_option('elementor_css_print_method', 'external');

        // get Elementor CPT support

        $elementor_cpt_support = get_option('elementor_cpt_support', array());


        $settings = array(
            'show_on_front' => $show_on_front,
            'page_on_front' => $home_page_slug,
            'page_for_posts' => $page_for_posts_slug,
            'date_format' => get_option('date_format'),
            'time_format' => get_option('time_format'),
            'posts_per_page' => get_option('posts_per_page'),
            'permalink_structure' => get_option('permalink_structure'),
            'woocommerce_shop_page' => $woocommerce_shop_page_slug,
            'woocommerce_cart_page' => $woocommerce_cart_page_slug,
            'woocommerce_checkout_page' => $woocommerce_checkout_page_slug,
            'woocommerce_myaccount_page' => $woocommerce_myaccount_page_slug,
            'elementor_css_print_method' => $elementor_css_print_method,
            'elementor_cpt_support' => $elementor_cpt_support,
        );
        return $settings;
    }

    public function saveSettings(array $data)
    {
        $upload_dir = wp_upload_dir();
        $file_name = 'settings.json';
        $file_path = trailingslashit($upload_dir['basedir']) . $file_name;


        if (file_put_contents($file_path, json_encode($data))) {
            $response = array(
                'success' => true,
                'message' => 'Export Settings successfully',
                'data' => $data,
            );
        } else {
            $response = array(
                'success' => false,
                'message' => 'Failed to export settings',
            );
        }

        return $response;
    }

    public function importSettings()
    {
        $file_path = tech888f_get_theme_path('/core/import/data/settings.json');

        if (file_exists($file_path)) {
            $data = file_get_contents($file_path);
            $data = json_decode($data, true);

            if (json_last_error() === JSON_ERROR_NONE) {
                $success = true;

                // Save the settings to the database
                $success &= update_option('show_on_front', $data['show_on_front']);
                $success &= update_option('page_on_front', get_page_by_path($data['page_on_front'])->ID);
                $success &= update_option('page_for_posts', get_page_by_path($data['page_for_posts'])->ID);
                $success &= update_option('date_format', $data['date_format']);
                $success &= update_option('time_format', $data['time_format']);
                $success &= update_option('posts_per_page', $data['posts_per_page']);
                $success &= update_option('permalink_structure', $data['permalink_structure']);
                $success &= update_option('woocommerce_shop_page_id', get_page_by_path($data['woocommerce_shop_page'])->ID);
                $success &= update_option('woocommerce_cart_page_id', get_page_by_path($data['woocommerce_cart_page'])->ID);
                $success &= update_option('woocommerce_checkout_page_id', get_page_by_path($data['woocommerce_checkout_page'])->ID);
                $success &= update_option('woocommerce_myaccount_page_id', get_page_by_path($data['woocommerce_myaccount_page'])->ID);
                $success &= update_option('elementor_css_print_method', $data['elementor_css_print_method']);
                // update elementor cpt support
                $elementor_cpt_support = $data['elementor_cpt_support'];
                $success &= update_option('elementor_cpt_support', $elementor_cpt_support);
                
                return array(
                    'success' => $success,  
                    'message' => $success ? 'Settings imported successfully' : 'Settings import failed',
                    'data' => $data,
                );
            } else {
                return array(
                    'success' => false,
                    'message' => 'Failed to decode JSON',
                );
            }
        } else {
            return array(
                'success' => false,
                'message' => 'File not found',
            );
        }
    }
}
