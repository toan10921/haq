<?php

namespace T888Helper;

class SampleDataService
{
    public function __construct()
    {
        // Constructor code here
    }

    public function importSampleData(
        $action_type = 'create',
        $post_type = 'post',
        $excerpts = array(),
        $contents = array(),
        $post_count = 10,
        $titles = array(),
        $cats = array(),
        $field_type_update = '',
        $thumbnails_update = array(),
        $thumbs_hover_update = array(),
        $galleries = array(),
        $cats_update = array(),
        $tags_update = array(),
        $excerpt_update = '',
        $content_update = '',
        $title = '',
        $post_ids_exclude = array()
    ) {
        $post_type = sanitize_text_field($post_type);
        switch ($action_type) {
            case 'update':
                // Handle sample data import
                $this->update_posts(
                    $post_type,
                    $field_type_update,
                    $thumbnails_update,
                    $thumbs_hover_update,
                    $galleries,
                    $cats_update,
                    $tags_update,
                    $excerpt_update,
                    $content_update,
                    $title,
                    $post_ids_exclude
                );
                break;
            default:
            case 'create':
                $post_count = intval($post_count);
                return $this->create_posts($post_type, $excerpts, $contents, $post_count, $titles, $cats);
                break;
        }

        return array('success' => true , 'message' => __('Sample data processed successfully.', 't888-helper'));
    }

    public function update_posts(
        $post_type,
        $field_type_update = '',
        $thumbnails_update = array(),
        $thumbs_hover_update = array(),
        $galleries = array(),
        $cats_update = array(),
        $tags_update = array(),
        $excerpt_update = '',
        $content_update = '',
        $title = '',
        $post_ids_exclude = array()
    ) {
        $args = array(
            'post_type'      => $post_type,
            'posts_per_page' => -1,
            'post__not_in'   => $post_ids_exclude
        );
        $product_query = new \WP_Query($args);
        $count = 0;
        if ($product_query->have_posts()) {
            while ($product_query->have_posts()) {
                $product_query->the_post();
                switch ($field_type_update) {
                    case 'thumb_hover':
                        if (is_array($thumbs_hover_update)) {
                            $count++;
                            update_post_meta(get_the_ID(), 'product_thumnail_hover', $thumbs_hover_update[$count]);
                            if ($count == count($thumbs_hover_update)) $count = -1;
                        } else update_post_meta(get_the_ID(), 'product_thumnail_hover',  $thumbs_hover_update);
                        break;
                    // update product featured
                    case 'feature':
                        $check = rand(1, 3);
                        if ($check % 2 == 0) update_post_meta(get_the_ID(), '_featured', 1);
                        break;

                    case 'cats':
                        wp_set_object_terms(get_the_ID(), $cats_update, 'product_cat');
                        break;

                    case 'tags':
                        if (is_array($tags_update)) {
                            $tags_key = array_rand($tags_update, 3);
                            $tags = array_intersect_key($tags_update, array_flip($tags_key));
                        } else $tags = $tags_update;
                        wp_set_object_terms(get_the_ID(), $tags, 'product_tag');
                        break;

                    case 'excerpt':
                        $my_post = array(
                            'ID'                => get_the_ID(),
                            'post_excerpt'      => $excerpt_update,
                        );
                        wp_update_post($my_post);
                        break;

                    case 'content':
                        $my_post = array(
                            'ID'                => get_the_ID(),
                            'post_content'      => $content_update,
                        );
                        wp_update_post($my_post);
                        break;

                    case 'title':
                        $my_post = array(
                            'ID'                => get_the_ID(),
                            'post_title'        => $title,
                        );
                        wp_update_post($my_post);
                        break;

                    case 'gallery':
                        if (is_array($galleries)) {
                            $gallery = array();
                            foreach ($galleries as $gallery_item) {
                                $gallery[] = wp_get_attachment_image_url($gallery_item, 'full');
                            }
                        } else {
                            $gallery = wp_get_attachment_image_url($galleries, 'full');
                        }
                        update_post_meta(get_the_ID(), '_product_image_gallery', $gallery);
                        break;

                    case 'thumbnail':
                        if (is_array($thumbnails_update)) {
                            update_post_meta(get_the_ID(), '_thumbnail_id', $thumbnails_update[$count]);
                            $count++;
                            if ($count == count($thumbnails_update)) $count = 0;
                        } else update_post_meta(get_the_ID(), '_thumbnail_id', $thumbnails_update);
                        break;

                    default:
                        break;
                }

            }
        }
        // This is a placeholder for the update logic
        return array('success' => true, 'message' => 'Posts updated successfully');
    }

    public function create_posts($post_type, $excerpts, $contents, $post_count, $titles, $cats = array())
    {
        for ($i = 0; $i < $post_count; $i++) {
            $title = $titles[$i % count($titles)];
            $content = $contents[$i % count($contents)];
            $excerpt = $excerpts[$i % count($excerpts)];
            $cats = !empty($cats) ? $cats : array('Uncategorized');
            $post_data = array(
                'post_title'   => $title,
                'post_content' => $content,
                'post_excerpt' => $excerpt,
                'post_status'  => 'publish',
                'post_type'    => $post_type,
                'post_author'  => get_current_user_id()

            );

            // Insert the post into the database
            $post_id = wp_insert_post($post_data);

            if ($post_type === 'post') {
                wp_set_post_terms($post_id, $cats, 'category');
            }

            // check if post type is product
            if ($post_type === 'product') {
                $price = rand(50, 500);
                $price_sale = '';
                $sku = 'No-' . rand(1000, 9999) . '-' . rand(1, 99);
                if ($price % 2 == 0) {
                    $price_sale = $price - rand(5, $price - 30) % 100;
                }
                // update price
                update_post_meta($post_id, '_regular_price', $price);
                update_post_meta($post_id, '_sale_price', $price_sale);
                update_post_meta($post_id, '_price', $price_sale ?: $price); // price in product page

                // SKU & stock status
                update_post_meta($post_id, '_sku', $sku);
                // update_post_meta($post_id, '_stock_status', 'instock');  // stock status
                update_post_meta($post_id, '_manage_stock', 'no');       // manage stock
                update_post_meta($post_id, '_product_version', '1.0.0'); // product version
                update_post_meta($post_id, '_virtual', 'no');            // virtual product
                update_post_meta($post_id, '_downloadable', 'no');      // downloadable product
                update_post_meta($post_id, '_visibility', 'visible');    // product visibility

                // set product type
                wp_set_object_terms($post_id, 'simple', 'product_type');

                // set product category
                if (!empty($cats)) {
                    // get random cats if cats is an array
                    if (is_array($cats) && count($cats) > 3) {
                        $catArrs = array();
                        $indexes = array_rand($cats, 3);
                        foreach ($indexes as $index) {
                            $catArrs[] = $cats[$index];
                        }
                    } else {
                        $catArrs = $cats;
                    }
                    wp_set_object_terms($post_id, $catArrs, 'product_cat');
                } else {
                    wp_set_object_terms($post_id, 'Uncategorized', 'product_cat');
                }
            }
        }
        return array('success' => true, 'message' => 'Posts created successfully');
    }
}
