<?php

namespace T888Helper;

class ContentService
{
    public function __construct()
    {
        // Constructor code here
    }

    public function importContent($fetch_attachments = false)
    {
        if (class_exists('WP_Import')) {
            $import_data_folder = tech888f_get_theme_path('/core/import/data/xml');

            $content_files = array_filter(
                glob($import_data_folder . '/*.xml'),
                function ($file) {
                    return basename($file) !== 'menus.xml';
                }
            );
            $importer = new \WP_Import();
            $importer->fetch_attachments = $fetch_attachments;
            ob_start(); //  prevent output to the screen
            foreach ($content_files as $file_path) {
                $importer->import($file_path);
            }
            $output = ob_end_clean();
            if (strpos($output, 'Failed to import') !== false || strpos($output, 'Invalid file') !== false) {
                return false; // Import failed
            } else {
                return true; // Import successful
            }
        }
    }

 public function importMedia() {
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';

    if (function_exists('wp_raise_memory_limit')) wp_raise_memory_limit('admin');
    @set_time_limit(0);
    @ini_set('max_execution_time', '0');

    $zip_path = tech888f_get_theme_path('/core/import/data/attachments.zip');
    if (!file_exists($zip_path)) {
        return new \WP_Error('zip_not_found', 'Không tìm thấy attachments.zip trong theme.');
    }

    $upload = wp_upload_dir();
    if (!empty($upload['error'])) {
        return new \WP_Error('upload_dir_error', $upload['error']);
    }

    // Thư mục tạm trong uploads
    $temp_dir = trailingslashit($upload['basedir']) . 't888-import-tmp-' . wp_generate_password(6, false);
    if (!wp_mkdir_p($temp_dir)) {
        return new \WP_Error('mkdir_failed', 'Không tạo được thư mục tạm trong uploads.');
    }

    // --- 1) init WP_Filesystem to use unzip_file ---
    $creds = request_filesystem_credentials('', '', false, false, null);
    if (!WP_Filesystem($creds)) {
        // if can not access FS, try fallback ZipArchive
        $zip = new \ZipArchive();
        if ($zip->open($zip_path) === true) {
            $zip->extractTo($temp_dir);
            $zip->close();
        } else {
            $this->rrmdir($temp_dir);
            return new \WP_Error('fs_unavailable', 'Could not access filesystem & ZipArchive mở file thất bại.');
        }
    } else {
        // use api wp to unzip
        $unz = unzip_file($zip_path, $temp_dir);
        if (is_wp_error($unz)) {
            $this->rrmdir($temp_dir);
            return $unz;
        }
    }

    // --- 2) iterate files & register to Media Library ---
    $allowed_mimes = get_allowed_mime_types();
    $rii = new \RecursiveIteratorIterator(
        new \RecursiveDirectoryIterator($temp_dir, \FilesystemIterator::SKIP_DOTS)
    );

    $imported = 0; $errors = []; $skipped = 0;

    foreach ($rii as $fileInfo) {
        if (!$fileInfo->isFile()) continue;
        $src_path = $fileInfo->getPathname();

        if (preg_match('~(/\.|__MACOSX|\.DS_Store)~', $src_path)) { $skipped++; continue; }

        $ft = wp_check_filetype_and_ext($src_path, basename($src_path));
        if (empty($ft['type']) || (!in_array($ft['type'], $allowed_mimes, true) && empty($allowed_mimes[$ft['ext']]))) {
            $skipped++; continue;
        }

        $dest_dir = $upload['path']; // uploads/Y/m
        if (!wp_mkdir_p($dest_dir)) { $errors[] = "Không tạo được upload subdir: {$dest_dir}"; continue; }

        $dest_name = wp_unique_filename($dest_dir, basename($src_path));
        $dest_path = trailingslashit($dest_dir) . $dest_name;

        if (!@copy($src_path, $dest_path)) {
            $errors[] = "Copy thất bại: {$src_path}";
            continue;
        }

        $filetype = wp_check_filetype(basename($dest_path), null);
        $attachment = [
            'post_mime_type' => $filetype['type'],
            'post_title'     => preg_replace('/\.[^.]+$/', '', $dest_name),
            'post_content'   => '',
            'post_status'    => 'inherit',
        ];

        $attach_id = wp_insert_attachment($attachment, $dest_path, 0);
        if (is_wp_error($attach_id)) { $errors[] = "wp_insert_attachment lỗi: {$dest_name} – " . $attach_id->get_error_message(); continue; }

        $metadata = wp_generate_attachment_metadata($attach_id, $dest_path);
        if (is_wp_error($metadata)) { $errors[] = "wp_generate_attachment_metadata lỗi: {$dest_name} – " . $metadata->get_error_message(); continue; }
        wp_update_attachment_metadata($attach_id, $metadata);

        $imported++;
    }

    $this->rrmdir($temp_dir);

    if ($imported === 0) {
        if (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) foreach ($errors as $e) error_log('[Media import] ' . $e);
        return new \WP_Error('nothing_imported', 'Không import được file media nào.');
    }

    return true;
}

// helper delete folder temp dir
private function rrmdir($dir) {
    if (!is_dir($dir)) return;
    $it = new \RecursiveDirectoryIterator($dir, \FilesystemIterator::SKIP_DOTS);
    $files = new \RecursiveIteratorIterator($it, \RecursiveIteratorIterator::CHILD_FIRST);
    foreach ($files as $file) { $file->isDir() ? @rmdir($file->getRealPath()) : @unlink($file->getRealPath()); }
    @rmdir($dir);
}

/* ===== Helpers to normalize image URLs ===== */
private function normalize_img_url($url){
    if(!$url) return '';
    $url = html_entity_decode($url);
    $url = strtok($url,'?');                               // bỏ query
    return preg_replace('~-(\d+)[xX](\d+)(\.\w+)$~','$3',$url); // bỏ -300x300
}

private function collect_urls_from_elementor($data,&$bucket){
    if(is_array($data)){
        foreach($data as $k=>$v){
            if (in_array($k,['url','image','image_url','background_image'], true)){
                if (is_string($v)) $bucket[] = $this->normalize_img_url($v);
                elseif(is_array($v) && !empty($v['url'])) $bucket[] = $this->normalize_img_url($v['url']);
            }
            $this->collect_urls_from_elementor($v,$bucket);
        }
    }
}

private function get_post_image_urls($post_id){
    $urls = [];
    $content = get_post_field('post_content',$post_id);
    if($content){
        if(preg_match_all('/<img[^>]+src=["\']([^"\']+)/i',$content,$m)){
            foreach($m[1] as $u) $urls[] = $this->normalize_img_url($u);
        }
        if(preg_match_all('/"url"\s*:\s*"([^"]+)"/i',$content,$m2)){
            foreach($m2[1] as $u) $urls[] = $this->normalize_img_url($u);
        }
    }
    $edata = get_post_meta($post_id,'_elementor_data',true);
    if($edata){
        $json = is_array($edata) ? $edata : json_decode($edata,true);
        if(json_last_error() === JSON_ERROR_NONE && is_array($json)){
            $this->collect_urls_from_elementor($json,$urls);
        }
    }
    return array_values(array_unique(array_filter($urls)));
}

private function findAttachmentIdByKey($key){
    global $wpdb;
    if(!$key) return 0;
    $key = sanitize_title($key);

    // ưu tiên khớp chính xác
    $id = (int) $wpdb->get_var($wpdb->prepare("
        SELECT ID FROM {$wpdb->posts}
        WHERE post_type='attachment'
          AND (post_name=%s OR post_title=%s OR guid LIKE %s)
        ORDER BY post_date DESC LIMIT 1
    ", $key, $key, '%/'.$wpdb->esc_like($key).'.%'));
    if($id) return $id;

    // khớp gần đúng
    $id = (int) $wpdb->get_var($wpdb->prepare("
        SELECT ID FROM {$wpdb->posts}
        WHERE post_type='attachment'
          AND (post_name LIKE %s OR post_title LIKE %s OR guid LIKE %s)
        ORDER BY post_date DESC LIMIT 1
    ", '%'.$wpdb->esc_like($key).'%', '%'.$wpdb->esc_like($key).'%', '%'.$wpdb->esc_like($key).'%'));

    return $id ?: 0;
}

/**
 * Assign Featured Image automatically for post/product.
 * Priority: SKU (product) → slug → title → images appearing in content/Elementor.
 * $fill_gallery=true will also populate gallery for product from remaining URLs.
 */
public function assignThumbnailsAuto(array $post_types=['post','product'], $fill_gallery=true){
    global $wpdb;
    $assigned = 0; $gallery_added = 0;

    foreach($post_types as $pt){
        $ids = $wpdb->get_col($wpdb->prepare("
            SELECT p.ID
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} m
              ON p.ID=m.post_id AND m.meta_key='_thumbnail_id'
            WHERE p.post_type=%s AND p.post_status IN ('publish','draft')
              AND (m.meta_value IS NULL OR m.meta_value='')
        ", $pt));

        foreach($ids as $pid){
            $thumb = 0;
            $slug  = get_post_field('post_name',$pid);
            $title = sanitize_title(get_the_title($pid));
            $sku   = ($pt==='product') ? get_post_meta($pid,'_sku',true) : '';

            foreach(array_filter([$sku,$slug,$title]) as $k){
                $thumb = $this->findAttachmentIdByKey($k);
                if($thumb) break;
            }

            if(!$thumb){
                foreach($this->get_post_image_urls($pid) as $u){
                    $id = attachment_url_to_postid($u);
                    if(!$id) $id = attachment_url_to_postid($this->normalize_img_url($u));
                    if($id){ $thumb=$id; break; }
                }
                // Nếu vẫn chưa tìm thấy, thử so sánh basename với các attachment
                if(!$thumb){
                    foreach($this->get_post_image_urls($pid) as $u){
                        $basename = basename($this->normalize_img_url($u));
                        if($basename){
                            $thumb = $this->findAttachmentIdByBasename($basename);
                            if($thumb) break;
                        }
                    }
                }
            }

            if($thumb){
                set_post_thumbnail($pid,$thumb);
                $assigned++;
            }

            /* fill gallery cho product */
            if($fill_gallery && $pt==='product'){
                $urls = $this->get_post_image_urls($pid);
                $gids = [];
                foreach($urls as $u){
                    $aid = attachment_url_to_postid($u);
                    if(!$aid) $aid = attachment_url_to_postid($this->normalize_img_url($u));
                    // Nếu vẫn chưa tìm thấy, thử so sánh basename
                    if(!$aid){
                        $basename = basename($this->normalize_img_url($u));
                        if($basename){
                            $aid = $this->findAttachmentIdByBasename($basename);
                        }
                    }
                    if($aid) $gids[] = $aid;
                }
                $gids = array_values(array_unique(array_filter($gids)));
                $thumb_id = get_post_thumbnail_id($pid);
                if($thumb_id) $gids = array_values(array_diff($gids, [$thumb_id]));
                if(!empty($gids)){
                    update_post_meta($pid,'_product_image_gallery', implode(',', array_slice($gids,0,8)));
                    $gallery_added += count($gids);
                }
            }
        }
    }
    return ['assigned'=>$assigned,'gallery_added'=>$gallery_added];
}

/**
 * Find attachment ID by basename image file
 */
private function findAttachmentIdByBasename($basename){
    global $wpdb;
    if(!$basename) return 0;
    $id = (int) $wpdb->get_var($wpdb->prepare("
        SELECT ID FROM {$wpdb->posts}
        WHERE post_type='attachment'
          AND guid LIKE %s
        ORDER BY post_date DESC LIMIT 1
    ", '%/' . $basename));
    return $id ?: 0;
}

}
