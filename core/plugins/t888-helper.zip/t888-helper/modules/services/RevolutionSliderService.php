<?php

namespace T888Helper;

class RevolutionSliderService
{
    public function __construct()
    {
        // Constructor
    }

    /**
     * Import Revolution Slider data
     */
    public function importRevolutionSlider($file_path = null, $update_existing = true)
    {
        // Check if RevSlider is active
        if (!class_exists('RevSlider') && !class_exists('RevSliderSlider')) {
            return array(
                'success' => false,
                'message' => 'Revolution Slider plugin is not installed or activated.',
            );
        }

        // Initialize WordPress filesystem
        global $wp_filesystem;
        if (empty($wp_filesystem)) {
            require_once(ABSPATH . '/wp-admin/includes/file.php');
            WP_Filesystem();
        }

        try {
            // Load required Revolution Slider files
            if (defined('RS_PLUGIN_PATH')) {
                $required_files = array(
                    'includes/functions.class.php',
                    'includes/globals.class.php', 
                    'includes/slider.class.php',
                    'includes/slide.class.php',
                    'admin/includes/template.class.php',
                    'admin/includes/import.class.php'
                );
                
                // Optional files that may not exist in all versions
                $optional_files = array(
                    'admin/includes/plugin_update.class.php',
                    'includes/css_parser.class.php'
                );
                
                foreach ($required_files as $file) {
                    $full_path = RS_PLUGIN_PATH . $file;
                    if (file_exists($full_path)) {
                        require_once($full_path);
                    }
                }
                
                foreach ($optional_files as $file) {
                    $full_path = RS_PLUGIN_PATH . $file;
                    if (file_exists($full_path)) {
                        require_once($full_path);
                    }
                }
                
                // Initialize globals if needed
                if (class_exists('RevSliderGlobals')) {
                    \RevSliderGlobals::instance();
                }
            }

            // Use theme path instead of uploads directory
            $import_path = tech888f_get_theme_path('/core/import/data/revolution-slider/');

            // If no specific file path provided, look for revolution slider files in theme directory
            if (!$file_path) {
                if (!file_exists($import_path)) {
                    return array(
                        'success' => false,
                        'message' => 'Revolution Slider import directory not found in theme: ' . $import_path,
                    );
                }

                // Get all .zip files in the import directory
                $files = glob($import_path . '*.zip');
                if (empty($files)) {
                    return array(
                        'success' => false,
                        'message' => 'No Revolution Slider files found in theme directory: ' . $import_path,
                    );
                }
            } else {
                $files = array($file_path);
            }

            $imported_sliders = array();
            $errors = array();

            foreach ($files as $file) {
                if (!file_exists($file)) {
                    $errors[] = sprintf('File not found: %s', basename($file));
                    continue;
                }

                try {
                    $result = $this->importSliderFile($file, $update_existing);

                    if ($result === true || (is_array($result) && isset($result['success']) && $result['success'])) {
                        $imported_sliders[] = basename($file);
                    } else {
                        $error_msg = is_wp_error($result) ? $result->get_error_message() : 'Unknown error occurred';
                        $errors[] = sprintf('Failed to import %s: %s', basename($file), $error_msg);
                    }

                } catch (\Exception $e) {
                    $errors[] = sprintf('Error importing %s: %s', basename($file), $e->getMessage());
                }
            }

            // Prepare response
            $success = !empty($imported_sliders);
            $message = '';

            if ($success) {
                $message = sprintf('Successfully imported %d Revolution Slider(s): %s', 
                    count($imported_sliders), 
                    implode(', ', $imported_sliders)
                );
            }

            if (!empty($errors)) {
                $message .= ($success ? ' ' : '') . 'Errors: ' . implode('; ', $errors);
            }

            if (!$success && empty($imported_sliders)) {
                $message = 'Failed to import any Revolution Sliders.';
                if (!empty($errors)) {
                    $message .= ' ' . implode('; ', $errors);
                }
            }

            return array(
                'success' => $success,
                'message' => $message,
                'data' => array(
                    'imported' => $imported_sliders,
                    'errors' => $errors
                )
            );

        } catch (\Exception $e) {
            return array(
                'success' => false,
                'message' => 'Error during Revolution Slider import: ' . $e->getMessage(),
            );
        }
    }

    /**
     * Helper method to import slider file
     */
    private function importSliderFile($file_path, $update_existing = true)
    {
        if (!file_exists($file_path)) {
            return new \WP_Error('file_not_found', 'Import file not found.');
        }

        try {
            // Check if Revolution Slider import class exists
            if (!class_exists('RevSliderSliderImport')) {
                // Try to load the import class
                $import_file = RS_PLUGIN_PATH . 'admin/includes/import.class.php';
                if (file_exists($import_file)) {
                    require_once($import_file);
                }
            }

            // Method 1: Use RevSliderSliderImport (Revolution Slider 6.0+)
            if (class_exists('RevSliderSliderImport')) {
                // Simulate $_FILES for the import function
                $_FILES['import_file'] = array(
                    'name' => basename($file_path),
                    'tmp_name' => $file_path,
                    'size' => filesize($file_path),
                    'error' => 0,
                    'type' => 'application/zip'
                );
                
                $import = new \RevSliderSliderImport();
                $result = $import->import_slider($update_existing, $file_path, false, false, $update_existing);
                
                // Clean up $_FILES
                unset($_FILES['import_file']);
                
                if (is_array($result) && isset($result['success']) && $result['success'] === false) {
                    return new \WP_Error('import_failed', isset($result['error']) ? $result['error'] : 'Import failed');
                }
                
                return true;
            }

            // Method 2: Use legacy RevSliderSlider if available
            if (class_exists('RevSliderSlider')) {
                $slider = new \RevSliderSlider();
                
                // Try the deprecated importSliderFromPost method
                if (method_exists($slider, 'importSliderFromPost')) {
                    // Simulate $_FILES for import
                    $_FILES['import_file'] = array(
                        'name' => basename($file_path),
                        'tmp_name' => $file_path,
                        'size' => filesize($file_path),
                        'error' => 0,
                        'type' => 'application/zip'
                    );
                    
                    $response = $slider->importSliderFromPost($update_existing, '', false, array(), $update_existing);
                    
                    // Clean up $_FILES
                    unset($_FILES['import_file']);
                    
                    return $response;
                }
            }

            // Method 3: Direct file processing as fallback
            return $this->directFileImport($file_path, $update_existing);

        } catch (\Exception $e) {
            // Clean up $_FILES if set
            if (isset($_FILES['import_file'])) {
                unset($_FILES['import_file']);
            }
            return new \WP_Error('import_error', $e->getMessage());
        }
    }

    /**
     * Process slider data directly
     */
    private function processSliderData($slider_data, $update_existing = true)
    {
        try {
            $data = json_decode($slider_data, true);
            
            if (json_last_error() !== JSON_ERROR_NONE) {
                // Try unserializing if JSON decode fails
                $data = maybe_unserialize($slider_data);
                if ($data === false) {
                    return new \WP_Error('invalid_data', 'Invalid Revolution Slider data format.');
                }
            }

            // Process slider data
            if (isset($data['id']) || isset($data['alias'])) {
                // This is slider data, process it
                global $wpdb;
                
                $slider_table = $wpdb->prefix . 'revslider_sliders';
                $slides_table = $wpdb->prefix . 'revslider_slides';
                
                // Check if tables exist
                if ($wpdb->get_var("SHOW TABLES LIKE '$slider_table'") != $slider_table) {
                    return new \WP_Error('table_missing', 'Revolution Slider database tables not found.');
                }

                // Insert or update slider
                $slider_data_to_insert = array(
                    'title' => isset($data['title']) ? $data['title'] : 'Imported Slider',
                    'alias' => isset($data['alias']) ? $data['alias'] : 'imported-slider-' . time(),
                    'params' => isset($data['params']) ? $data['params'] : '{}',
                    'settings' => isset($data['settings']) ? $data['settings'] : '{}'
                );

                if ($update_existing && isset($data['alias'])) {
                    $existing = $wpdb->get_row($wpdb->prepare(
                        "SELECT id FROM $slider_table WHERE alias = %s",
                        $data['alias']
                    ));
                    
                    if ($existing) {
                        $wpdb->update(
                            $slider_table,
                            $slider_data_to_insert,
                            array('id' => $existing->id)
                        );
                        $slider_id = $existing->id;
                    } else {
                        $wpdb->insert($slider_table, $slider_data_to_insert);
                        $slider_id = $wpdb->insert_id;
                    }
                } else {
                    $wpdb->insert($slider_table, $slider_data_to_insert);
                    $slider_id = $wpdb->insert_id;
                }

                // Import slides if available
                if (isset($data['slides']) && is_array($data['slides'])) {
                    foreach ($data['slides'] as $slide_data) {
                        $slide_to_insert = array(
                            'slider_id' => $slider_id,
                            'slide_order' => isset($slide_data['slide_order']) ? $slide_data['slide_order'] : 0,
                            'params' => isset($slide_data['params']) ? $slide_data['params'] : '{}',
                            'layers' => isset($slide_data['layers']) ? $slide_data['layers'] : '{}'
                        );
                        
                        $wpdb->insert($slides_table, $slide_to_insert);
                    }
                }

                return true;
            }

            return new \WP_Error('invalid_format', 'Unrecognized slider data format.');

        } catch (\Exception $e) {
            return new \WP_Error('process_error', $e->getMessage());
        }
    }

    /**
     * Direct file import method
     */
    private function directFileImport($file_path, $update_existing = true)
    {
        try {
            $zip = new \ZipArchive();
            $result = $zip->open($file_path);
            
            if ($result !== TRUE) {
                return new \WP_Error('zip_error', 'Cannot open zip file: ' . $result);
            }

            // Look for slider export file
            $export_files = array('slider_export.txt', 'slider.txt', 'export.txt');
            $slider_data = '';
            
            foreach ($export_files as $export_file) {
                if ($zip->locateName($export_file) !== false) {
                    $slider_data = $zip->getFromName($export_file);
                    break;
                }
            }

            $zip->close();

            if (empty($slider_data)) {
                return new \WP_Error('no_data', 'No valid slider data found in zip file.');
            }

            return $this->processSliderData($slider_data, $update_existing);

        } catch (\Exception $e) {
            return new \WP_Error('direct_import_error', $e->getMessage());
        }
    }

    /**
     * Check if Revolution Slider plugin is active and functional
     */
    public function isRevolutionSliderActive()
    {
        return class_exists('RevSlider') || class_exists('RevSliderSlider');
    }

    /**
     * Get Revolution Slider import/export directory paths
     */
    public function getDirectoryPaths()
    {
        return array(
            'import_path' => tech888f_get_theme_path('/core/import/data/revolution-slider/'),
            'export_path' => tech888f_get_theme_path('/core/import/data/revolution-slider-export/'),
            'import_url' => get_template_directory_uri() . '/core/import/data/revolution-slider/',
            'export_url' => get_template_directory_uri() . '/core/import/data/revolution-slider-export/',
        );
    }

    /**
     * Create import directory if it doesn't exist
     */
    public function createImportDirectory()
    {
        $paths = $this->getDirectoryPaths();
        
        if (!file_exists($paths['import_path'])) {
            wp_mkdir_p($paths['import_path']);
        }
        
        return file_exists($paths['import_path']);
    }

    /**
     * Get list of files in import directory
     */
    public function getImportFiles()
    {
        $paths = $this->getDirectoryPaths();
        $files = array();
        
        if (file_exists($paths['import_path'])) {
            $file_list = glob($paths['import_path'] . '*.zip');
            foreach ($file_list as $file) {
                $files[] = array(
                    'name' => basename($file),
                    'path' => $file,
                    'size' => filesize($file),
                    'modified' => filemtime($file)
                );
            }
        }
        
        return $files;
    }
}
