<?php

namespace T888Helper;

class MenuService
{

    public $menuModel = null;
    public function __construct()
    {
        $this->menuModel = new ExportImportModel();
    }

    public function export_menu($menu_id = 0)
    {
        $data = $this->menuModel->generateMenusJson(array(
            'menu' => $menu_id
        ));

        // write uploads folder using wordpress function
        error_log(json_encode($data));
        $upload_dir = wp_upload_dir();
        $file_name = 'menu-' . $menu_id . '.json';
        $file_path = trailingslashit($upload_dir['basedir']) . $file_name;
        if (file_put_contents($file_path, $data)) {
            $response = array(
                'success' => true,
                'message' => 'Exporting menus...',
                'data' => $data,
            );
        } else {
            $response = array(
                'success' => false,
                'message' => 'Failed to write the file to the uploads directory.',
            );
        }
        return $response;
    }

    public function importMenuFromJson(array $menu_items, string $menu_slug, string $menu_location = 'primary', string $menu_name = '')
    {
        // 1. Get or create the menu
        $menu = get_term_by('slug', $menu_slug, 'nav_menu');
        if (!$menu) {
            return;
        }

        $menu_id = $menu->term_id;

        // if (!$menu) {
        //     // If no name is provided, generate a name from the slug
        //     if (!$menu_name) {
        //         $menu_name = ucwords(str_replace('-', ' ', $menu_slug));
        //     }

        //     $menu_id = wp_create_nav_menu($menu_name);

        //     // Manually update the slug if exact matching is required
        //     global $wpdb;
        //     $wpdb->update(
        //         $wpdb->terms,
        //         ['slug' => sanitize_title($menu_slug)],
        //         ['term_id' => $menu_id]
        //     );
        // } else {
        //     $menu_id = $menu->term_id;
        // }

        // // 2. Map old_id => new_id
        // $id_map = [];

        // foreach ($menu_items as $item) {
        //     $post = $item['post'];
        //     $metas = $item['post_metas'];

        //     $new_item_id = wp_insert_post([
        //         'post_type'    => 'nav_menu_item',
        //         'post_status'  => 'publish',
        //         'menu_order'   => $post['menu_order'],
        //         'post_title'   => '',
        //         'post_content' => $post['post_content'],
        //         'post_parent'  => 0,
        //     ]);

        //     if (is_wp_error($new_item_id)) {
        //         error_log("Error when adding menu item: " . ($post['title'] ?? 'no title provided'));
        //         continue;
        //     }

        //     foreach ($metas as $key => $value) {
        //         $real_value = is_array($value) ? maybe_unserialize($value[0]) : $value;
        //         update_post_meta($new_item_id, $key, $real_value);
        //     }

        //     wp_set_object_terms($new_item_id, [$menu_id], 'nav_menu');
        //     $id_map[$post['db_id']] = $new_item_id;
        // }

        // // 3. Assign correct parent
        // foreach ($menu_items as $item) {
        //     $post = $item['post'];
        //     $old_id = $post['db_id'];
        //     $parent_old_id = (int)$post['menu_item_parent'];

        //     if ($parent_old_id > 0 && isset($id_map[$old_id]) && isset($id_map[$parent_old_id])) {
        //         wp_update_post([
        //             'ID' => $id_map[$old_id],
        //             'post_parent' => $id_map[$parent_old_id],
        //         ]);
        //     }
        // }

        // 4. Assign to location
        $locations = get_nav_menu_locations();
        $locations[$menu_location] = $menu_id;
        $ret = set_theme_mod('nav_menu_locations', $locations);

        return $ret;
    }

    public function importMenus()
    {

        $file_path = tech888f_get_theme_path('/core/import/data/xml/menus.xml');

        $importer = new \WP_Import();
        $importer->fetch_attachments = false;
        ob_start(); //  prevent output to the screen
        $importer->import($file_path);
        $output = ob_end_clean();
        if (strpos($output, 'Failed to import') !== false || strpos($output, 'Invalid file') !== false) {
            return false; // Import failed
        }
        return true; // Import successful

    }

    public function assignMenusToLocations()
    {
        // Đọc file mapping JSON
        $mapping_file = tech888f_get_theme_path('/core/import/menu_locations.json');

        if (!file_exists($mapping_file)) {
            error_log("Menu locations mapping file not found: {$mapping_file}");
            return;
        }

        $mapping_content = file_get_contents($mapping_file);
        $menu_mappings = json_decode($mapping_content, true);

        if (!$menu_mappings || !is_array($menu_mappings)) {
            error_log("Invalid menu locations mapping JSON");
            return;
        }

        // Lấy tất cả menu hiện có sau import
        $current_menus = wp_get_nav_menus();
        $locations = get_nav_menu_locations();

        // Tạo mapping slug => menu_id
        $menu_slug_to_id = [];
        foreach ($current_menus as $menu) {
            $menu_slug_to_id[$menu->slug] = $menu->term_id;
        }

        // Assign theo mapping JSON
        foreach ($menu_mappings as $mapping) {
            $menu_slug = $mapping['menu_slug'];
            $theme_location = $mapping['theme_location'];

            // Kiểm tra menu có tồn tại không
            if (isset($menu_slug_to_id[$menu_slug])) {
                $menu_id = $menu_slug_to_id[$menu_slug];
                $locations[$theme_location] = $menu_id;

                error_log("Assigned menu '{$menu_slug}' (ID: {$menu_id}) to location '{$theme_location}'");
            } else {
                error_log("Menu with slug '{$menu_slug}' not found after import");
            }
        }

        // Lưu menu locations
        set_theme_mod('nav_menu_locations', $locations);

        // Log kết quả
        error_log("Menu locations assignment completed from JSON mapping");
        return true;
    }
}
