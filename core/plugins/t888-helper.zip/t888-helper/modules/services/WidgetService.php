<?php

namespace T888Helper;

class WidgetService
{
    public function __construct() {}

    public function getSidebarWidgets()
    {
        $sidebars_widgets = get_option('sidebars_widgets');
        return $sidebars_widgets;
    }

    public function importWidgets()
    {
        $file_path = tech888f_get_theme_path('/core/import/data/sidebars_widgets.json');

        if (file_exists($file_path)) {
            $data = file_get_contents($file_path);

            $widget_data = json_decode($data, true);
            
            foreach ($widget_data as $key => $value) {
                if ($key === 'sidebars_widgets') {
                    continue; // skip to process later
                }
            
                // ensure correct key format
                if (is_array($value)) {
                    update_option($key, $value);
                }
            }

            if (isset($widget_data['sidebars_widgets'])) {
                update_option('sidebars_widgets', $widget_data['sidebars_widgets']);
            }

            return array(
                'success' => true,
                'message' => 'Import widgets successfully !',
                'data' => $widget_data,
            );
        }

        return false;
    }

    public function saveSidebarWidgets()
    {
        $sidebars_widgets = $this->getSidebarWidgets();
        if ($sidebars_widgets === false) {
            return array(
                'success' => false,
                'message' => 'Failed to unserialize data',
            );
        }
        $widget_keys = [];
        foreach ($sidebars_widgets as $sidebar => $widgets) {
            if (!is_array($widgets)) continue;
            foreach ($widgets as $widget_id) {
                if (preg_match('/^(.+)-\d+$/', $widget_id, $matches)) {
                    $widget_keys[] = 'widget_' . $matches[1];
                }
            }
        }

        // filter out duplicate widget keys
        $widget_keys = array_unique($widget_keys);

        error_log('Widget keys: ' . json_encode($widget_keys));

        // Export all widgets to a file
        $data = ['sidebars_widgets' => $sidebars_widgets];
        foreach ($widget_keys as $widget_key) {
            $data[$widget_key] = get_option($widget_key);
        }

        error_log('Widgets data: ' . json_encode($data));

        $upload_dir = wp_upload_dir();
        $file_name = 'sidebars_widgets.json';
        $file_path = trailingslashit($upload_dir['basedir']) . $file_name;

        // export to JSON file
        $ret = file_put_contents($file_path, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        if ($ret === false) {
            return array(
                'success' => false,
                'message' => 'Failed to write the file to the uploads directory.',
            );
        } else {
            return array(
                'success' => true,
                'message' => 'Export widgets successfully !',
                'data' => $data,
            );
        }
    }
}
