<?php

namespace T888Helper;

class ElementorKitService
{
    public function isElementorActive()
    {
        return defined('ELEMENTOR_VERSION') && class_exists('\Elementor\Plugin');
    }

    public function getKitFilePath()
    {
        return tech888f_get_theme_path('/core/import/data/elementor-kit.zip');
    }

    public function kitFileExists()
    {
        return file_exists($this->getKitFilePath());
    }

    public function importElementorKit($file_path = null, $include_settings = true)
    {
        if (!$this->isElementorActive()) {
            return [
                'success' => false,
                'message' => __('Elementor plugin is not active.', 't888-helper')
            ];
        }

        try {
            // Chỉ import site settings từ JSON file
            return $this->importSiteSettingsOnly();
        } catch (\Exception $e) {
            error_log('[Elementor Site Settings Import] ' . $e->getMessage());
            return [
                'success' => false,
                'message' => __('Import failed: ', 't888-helper') . $e->getMessage()
            ];
        }
    }

    private function importKitViaElementorNativeAPI($file_path, $include_settings)
    {
        // Load Elementor import classes
        if (!class_exists('\Elementor\TemplateLibrary\Source_Local')) {
            require_once ELEMENTOR_PATH . 'includes/template-library/sources/local.php';
        }

        // Backup original $_FILES and $_POST
        $original_files = $_FILES;
        $original_post = $_POST;

        // Create temporary file
        $temp_file = wp_tempnam(basename($file_path));
        if (!copy($file_path, $temp_file)) {
            return [
                'success' => false,
                'message' => 'Failed to copy kit file to temp location'
            ];
        }

        try {
            // Simulate file upload for Elementor
            $_FILES['file'] = [
                'name' => basename($file_path),
                'type' => 'application/zip',
                'tmp_name' => $temp_file,
                'error' => UPLOAD_ERR_OK,
                'size' => filesize($temp_file)
            ];

            // Set import options
            $_POST['import_settings'] = $include_settings ? '1' : '0';

            // Use Elementor's import kit handler
            $result = $this->executeElementorKitImport();

            // Cleanup
            if (file_exists($temp_file)) {
                unlink($temp_file);
            }
            $_FILES = $original_files;
            $_POST = $original_post;

            return $result;
        } catch (\Exception $e) {
            // Cleanup on error
            if (file_exists($temp_file)) {
                unlink($temp_file);
            }
            $_FILES = $original_files;
            $_POST = $original_post;

            throw $e;
        }
    }

    private function executeElementorKitImport()
    {
        // Check if we can use Elementor's kit import directly
        if (class_exists('\Elementor\Core\Kits\Manager')) {
            $kit_manager = \Elementor\Plugin::$instance->kits_manager;

            // Try to use import_kit method if available
            if (method_exists($kit_manager, 'import_kit')) {
                try {
                    $result = $kit_manager->import_kit($_FILES['file'], $_POST);

                    if ($result && !is_wp_error($result)) {
                        return [
                            'success' => true,
                            'message' => 'Elementor kit imported successfully using native API',
                            'data' => $result
                        ];
                    }
                } catch (\Exception $e) {
                    error_log('Native kit import failed: ' . $e->getMessage());
                }
            }
        }

        // Fallback: Use template library import system
        return $this->importKitViaTemplateLibrary();
    }

    private function importKitViaTemplateLibrary()
    {
        try {
            // Load required Elementor classes
            $this->loadElementorImportClasses();

            // Use Elementor's template library to import
            $source_local = new \Elementor\TemplateLibrary\Source_Local();

            if (method_exists($source_local, 'import_template')) {
                // Fix: import_template() cần 2 tham số
                $import_result = $source_local->import_template(
                    $_FILES['file'],                    // Tham số 1: file data
                    $_POST['import_settings'] ?? '0'    // Tham số 2: import settings
                );

                if (!is_wp_error($import_result)) {
                    // Set as active kit if it's a kit
                    if (isset($import_result[0]['template_id'])) {
                        $template_id = $import_result[0]['template_id'];
                        $template_type = get_post_meta($template_id, '_elementor_template_type', true);

                        if ($template_type === 'kit') {
                            update_option('elementor_active_kit', $template_id);

                            // Clear Elementor cache
                            if (class_exists('\Elementor\Plugin')) {
                                \Elementor\Plugin::$instance->files_manager->clear_cache();
                            }
                        }
                    }

                    return [
                        'success' => true,
                        'message' => 'Elementor kit imported via template library',
                        'data' => $import_result
                    ];
                }
            }

            // Final fallback: Manual kit processing
            return $this->manualKitImport();
        } catch (\Exception $e) {
            error_log('Template library import failed: ' . $e->getMessage());
            return $this->manualKitImport();
        }
    }

    private function loadElementorImportClasses()
    {
        // Load necessary Elementor classes
        $required_files = [
            'includes/template-library/sources/base.php',
            'includes/template-library/sources/local.php',
            'includes/template-library/manager.php'
        ];

        foreach ($required_files as $file) {
            $file_path = ELEMENTOR_PATH . $file;
            if (file_exists($file_path) && !class_exists(basename($file, '.php'))) {
                require_once $file_path;
            }
        }
    }

    private function manualKitImport()
    {
        try {
            // Extract kit data manually
            $kit_data = $this->extractKitDataManually($_FILES['file']['tmp_name']);

            if (!$kit_data) {
                return [
                    'success' => false,
                    'message' => 'Failed to extract kit data manually'
                ];
            }

            $imported_count = 0;
            $kit_id = null;

            // Import each template
            foreach ($kit_data['templates'] as $template) {
                $post_id = $this->createElementorTemplate($template);
                if ($post_id) {
                    $imported_count++;

                    // Check if this is the kit
                    if (isset($template['info']['type']) && $template['info']['type'] === 'kit') {
                        $kit_id = $post_id;
                        update_option('elementor_active_kit', $kit_id);
                    }
                }
            }

            // Import site settings if available and requested
            if ($_POST['import_settings'] === '1' && isset($kit_data['site_settings']) && $kit_id) {
                $this->applySiteSettings($kit_id, $kit_data['site_settings']);
            }

            // Clear cache
            if (class_exists('\Elementor\Plugin')) {
                \Elementor\Plugin::$instance->files_manager->clear_cache();
            }

            return [
                'success' => true,
                'message' => sprintf('Kit imported manually. Templates: %d, Kit ID: %s', $imported_count, $kit_id ?: 'N/A'),
                'data' => [
                    'templates_imported' => $imported_count,
                    'kit_id' => $kit_id
                ]
            ];
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => 'Manual import failed: ' . $e->getMessage()
            ];
        }
    }

    private function extractKitDataManually($zip_file)
    {
        $temp_dir = wp_upload_dir()['basedir'] . '/elementor-kit-manual-' . time();
        wp_mkdir_p($temp_dir);

        $zip = new \ZipArchive();
        if ($zip->open($zip_file) !== TRUE) {
            return false;
        }

        $zip->extractTo($temp_dir);
        $zip->close();

        $data = [
            'templates' => [],
            'site_settings' => null
        ];

        // Read manifest
        $manifest_file = $temp_dir . '/manifest.json';
        if (file_exists($manifest_file)) {
            $manifest = json_decode(file_get_contents($manifest_file), true);

            if (isset($manifest['templates'])) {
                foreach ($manifest['templates'] as $template_info) {
                    $template_file = $temp_dir . '/' . $template_info['file'];
                    if (file_exists($template_file)) {
                        $template_content = json_decode(file_get_contents($template_file), true);
                        if ($template_content) {
                            $data['templates'][] = [
                                'info' => $template_info,
                                'content' => $template_content
                            ];
                        }
                    }
                }
            }
        }

        // Read site settings
        $settings_file = $temp_dir . '/site-settings.json';
        if (file_exists($settings_file)) {
            $data['site_settings'] = json_decode(file_get_contents($settings_file), true);
        }

        // Cleanup temp directory
        $this->deleteDirectory($temp_dir);

        return $data;
    }

    private function createElementorTemplate($template_data)
    {
        $template_info = $template_data['info'];
        $template_content = $template_data['content'];

        $post_data = [
            'post_title' => $template_info['title'] ?? 'Imported Template',
            'post_type' => 'elementor_library',
            'post_status' => 'publish'
        ];

        $post_id = wp_insert_post($post_data);

        if ($post_id && !is_wp_error($post_id)) {
            // Set template meta
            update_post_meta($post_id, '_elementor_template_type', $template_info['type'] ?? 'page');
            update_post_meta($post_id, '_elementor_data', $template_content['content'] ?? []);
            update_post_meta($post_id, '_elementor_edit_mode', 'builder');
            update_post_meta($post_id, '_elementor_version', ELEMENTOR_VERSION);

            // Set page settings if available
            if (isset($template_content['page_settings'])) {
                update_post_meta($post_id, '_elementor_page_settings', $template_content['page_settings']);
            }

            error_log("Created Elementor template: {$post_id} ({$template_info['type']})");
            return $post_id;
        }

        return false;
    }

    private function applySiteSettings($kit_id, $site_settings)
    {
        if ($kit_id && $site_settings) {
            update_post_meta($kit_id, '_elementor_page_settings', $site_settings);
            error_log("Applied site settings to kit: {$kit_id}");
        }
    }

    private function deleteDirectory($dir)
    {
        if (!is_dir($dir)) return;

        $files = array_diff(scandir($dir), array('.', '..'));
        foreach ($files as $file) {
            $path = $dir . '/' . $file;
            is_dir($path) ? $this->deleteDirectory($path) : unlink($path);
        }
        rmdir($dir);
    }

    public function getKitInfo()
    {
        $file_path = $this->getKitFilePath();

        if (!$this->kitFileExists()) {
            return [
                'exists' => false,
                'path' => $file_path,
                'size' => 0,
                'readable' => false
            ];
        }

        return [
            'exists' => true,
            'path' => $file_path,
            'size' => filesize($file_path),
            'readable' => is_readable($file_path),
            'formatted_size' => size_format(filesize($file_path))
        ];
    }

    private function importSiteSettingsOnly()
    {
        // Lấy đường dẫn file site-settings.json
        $settings_file = tech888f_get_theme_path('/core/import/data/elementor-kit/site-settings.json');
        
        if (!file_exists($settings_file)) {
            return [
                'success' => false,
                'message' => __('Site settings file not found: ', 't888-helper') . basename($settings_file)
            ];
        }

        try {
            // Đọc file JSON
            $settings_content = file_get_contents($settings_file);
            $settings_data = json_decode($settings_content, true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                return [
                    'success' => false,
                    'message' => __('Invalid JSON format in site settings file.', 't888-helper')
                ];
            }

            // Lấy settings từ JSON
            $site_settings = isset($settings_data['settings']) ? $settings_data['settings'] : [];

            if (empty($site_settings)) {
                return [
                    'success' => false,
                    'message' => __('No settings found in site settings file.', 't888-helper')
                ];
            }

            // Apply settings vào active kit
            $result = $this->applySiteSettingsToActiveKit($site_settings);

            if ($result) {
                return [
                    'success' => true,
                    'message' => __('Elementor site settings imported successfully.', 't888-helper'),
                    'data' => [
                        'settings_count' => count($site_settings),
                        'applied_settings' => array_keys($site_settings)
                    ]
                ];
            } else {
                return [
                    'success' => false,
                    'message' => __('Failed to apply site settings to active kit.', 't888-helper')
                ];
            }

        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => __('Error importing site settings: ', 't888-helper') . $e->getMessage()
            ];
        }
    }

    private function applySiteSettingsToActiveKit($site_settings)
    {
        try {
            // Lấy active kit
            $kit = \Elementor\Plugin::$instance->kits_manager->get_active_kit();
            
            if (!$kit) {
                // Tạo kit mới nếu chưa có
                $kit_id = $this->createDefaultKit();
                if (!$kit_id) {
                    error_log('Failed to create default kit');
                    return false;
                }
                $kit = \Elementor\Plugin::$instance->kits_manager->get_active_kit();
            }

            if ($kit) {
                $kit_id = $kit->get_main_id();
                
                // Update site settings vào kit
                update_post_meta($kit_id, '_elementor_page_settings', $site_settings);
                
                // Clear Elementor cache
                if (method_exists(\Elementor\Plugin::$instance->files_manager, 'clear_cache')) {
                    \Elementor\Plugin::$instance->files_manager->clear_cache();
                }
                
                error_log("Applied site settings to kit ID: {$kit_id}");
                error_log("Settings applied: " . print_r(array_keys($site_settings), true));
                
                return true;
            }

            return false;

        } catch (\Exception $e) {
            error_log('Error applying site settings: ' . $e->getMessage());
            return false;
        }
    }

    private function createDefaultKit()
    {
        try {
            // Tạo kit post mới
            $kit_post = wp_insert_post([
                'post_title' => 'Default Kit',
                'post_type' => 'elementor_library',
                'post_status' => 'publish',
                'meta_input' => [
                    '_elementor_template_type' => 'kit',
                    '_elementor_edit_mode' => 'builder',
                    '_elementor_version' => ELEMENTOR_VERSION
                ]
            ]);

            if ($kit_post && !is_wp_error($kit_post)) {
                // Set làm active kit
                update_option('elementor_active_kit', $kit_post);
                error_log("Created new default kit with ID: {$kit_post}");
                return $kit_post;
            }

            return false;

        } catch (\Exception $e) {
            error_log('Error creating default kit: ' . $e->getMessage());
            return false;
        }
    }
}
