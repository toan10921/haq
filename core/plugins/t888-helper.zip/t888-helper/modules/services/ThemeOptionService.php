<?php

namespace T888Helper;

class ThemeOptionService
{
    private $themeSlug;

    public function __construct()
    {
        // Constructor code here if needed
        $this->themeSlug = T888_THEME_SLUG; // replace with specific theme slug
    }

    public function getThemeOptions()
{
    // slug của theme đang active (child theme nếu có)
    $stylesheet = get_option('stylesheet'); // hoặc get_stylesheet()
    $mods = get_option("theme_mods_{$stylesheet}");

    // fallback: thử lấy của parent theme nếu rỗng
    if ($mods === false) {
        $template = get_option('template'); // hoặc get_template()
        $mods = get_option("theme_mods_{$template}");
    }

    return is_array($mods) ? $mods : [];  // luôn trả về mảng
}


    public function importThemeOptions()
{
    $file_path = tech888f_get_theme_path('/core/import/data/theme_option.ser');
    if (!file_exists($file_path)) {
        return ['success' => false, 'message' => 'File not found'];
    }

    $raw  = file_get_contents($file_path);
    $data = base64_decode($raw, true);
    if ($data === false) {
        return ['success' => false, 'message' => 'Failed to base64-decode'];
    }

    $theme_options = @unserialize($data);
    if (!is_array($theme_options)) {
        return ['success' => false, 'message' => 'Failed to unserialize'];
    }

    $stylesheet = get_option('stylesheet'); // ghi vào theme đang active
    $ok = update_option("theme_mods_{$stylesheet}", $theme_options);
    return ['success' => (bool)$ok, 'message' => $ok ? 'Theme options imported' : 'Update failed'];
}


    public function saveThemeOptions($theme_options)
    {
        $upload_dir = wp_upload_dir();
        $file_name = 'theme_option.ser';
        $file_path = trailingslashit($upload_dir['basedir']) . $file_name;
        if (file_put_contents($file_path, $theme_options)) {
            $response = array(
                'success' => true,
                'message' => 'Export theme options successfully !',
                'data' => $theme_options,
            );
        } else {
            $response = array(
                'success' => false,
                'message' => 'Failed to write the file to the uploads directory.',
            );
        }
        return $response;
    }
}
