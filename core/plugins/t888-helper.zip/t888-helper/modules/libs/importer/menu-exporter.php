<?php
/**
 * Created by Sublime Text 2.
 * User: thanhhiep992
 * Date: 12/08/15
 * Time: 10:20 AM
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

if ( ! class_exists( 'WP_Export_Menus' ) ) {
    class WP_Export_Menus {
        
        public function __construct() {
            add_action( 'export_filters', array( &$this, 'export_filters' ) );  
            add_filter( 'export_args', array( &$this, 'export_args' ) );
            add_action( 'admin_head', array( &$this, 'wem_export_add_js' ) );
            // Language Translation
            add_action ( 'init',      array( &$this, 'wem_update_po_file' ) );
        }
        /**
         * This function will allowed customer to transalte the plugin string using .po and .pot file.
         * @hook init
         * @since 1.1
         */
        function  wem_update_po_file() {
            
            $domain = 'wp-export-menus';
            $locale = apply_filters( 'plugin_locale', get_locale(), $domain );
            if ( $loaded = load_textdomain( $domain, trailingslashit( WP_LANG_DIR ) . $domain . '-' . $locale . '.mo' ) ) {
                return $loaded;
            } else {
                load_plugin_textdomain( $domain, FALSE, basename( dirname( __FILE__ ) ) . '/i18n/languages/' );
            }
        }
        
        /**
         * Display JavaScript on the page.
         *
         * @since 3.5.0
         */
        public static function wem_export_add_js() {
            ?>
            <script type="text/javascript">
                jQuery(document).ready(function($){
                    var form = jQuery('#export-filters'),
                        filters = form.find( '.export-filters' );
                    filters.hide();
                    jQuery( '.nav-menu-item-filters' ).hide();
                    jQuery( 'input[name=content]' ).change(function() {
                        filters.slideUp( 'fast' );
                        jQuery( '.nav-menu-item-filters' ).slideUp( 'fast' );
                        switch ( jQuery(this).val() ) {
                            case 'nav_menu_item': console.log( 'HERE' ); jQuery('#nav-menu-item-filters').slideDown(); break;
                        }
                    });
                });
            </script>
            <?php
        }
        
        public function export_filters() {
            ?>
            <p><label><input type="radio" name="content" value="nav_menu_item" /> <?php _e( 'Navigation Menu Items', 'wp-export-menus' ); ?></label></p>
            <ul id="nav-menu-item-filters" class="nav-menu-item-filters">
                <li>
                    <fieldset>
                    <legend class="screen-reader-text"><?php _e( 'Date range:', 'wp-export-menus' ); ?></legend>
                    <label for="nav-menu-item-start-date" class="label-responsive"><?php _e( 'Start date:', 'wp-export-menus' ); ?></label>
                    <select name="nav_menu_item_start_date" id="nav-menu-item-start-date">
                        <option value="0"><?php _e( '&mdash; Select &mdash;', 'wp-export-menus' ); ?></option>
                        <?php export_date_options( 'nav_menu_item' ); ?>
                    </select>
                    <label for="nav-menu-item-end-date" class="label-responsive"><?php _e( 'End date:', 'wp-export-menus' ); ?></label>
                    <select name="nav-menu-item_end_date" id="nav-menu-item-end-date">
                        <option value="0"><?php _e( '&mdash; Select &mdash;', 'wp-export-menus' ); ?></option>
                        <?php export_date_options( 'nav_menu_item' ); ?>
                    </select>
                    </fieldset>
                </li>
            </ul>
            <?php
        }

        public static function export_args( $args ) {
            if( !isset( $_GET['download'] ) || empty( $_GET['content'] ) || $_GET['content'] !== 'nav_menu_item' )  {
                    return $args;;
            }
            self::wp_export_menu();
            exit;
        }

        /**
         * Generates the WXR export file for download - This is a rip of export_wp but supports only exporting menus and it's terms
         *
         *
         * @param array $args Filters defining what should be included in the export
         */
        public static function wp_export_menu( $args = array() ) {
            global $wpdb, $post;
            $sitename = sanitize_key( get_bloginfo( 'name' ) );
            if ( !empty( $sitename ) ) {
                $sitename .= '.';
            }
            $filename = $sitename . 'wordpress.' . date( 'Y-m-d' ) . '.xml';

            header( 'Content-Description: File Transfer' );
            header( 'Content-Disposition: attachment; filename=' . $filename );
            header( 'Content-Type: text/xml; charset=' . get_option( 'blog_charset' ), true );
            
            $where = $wpdb->prepare( "{$wpdb->posts}.post_type = %s AND post_status = 'publish'", 'nav_menu_item' );

            // grab a snapshot of post IDs, just in case it changes during the export
            $post_ids = $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE $where" );
            require_once(__DIR__ . '/views/view-menu-exporter.php');
        }
    
        /**
         * Wrap given string in XML CDATA tag.
         *
         * @since 2.1.0
         *
         * @param string $str String to wrap in XML CDATA tag.
         */
        public static function wem_cdata( $str ) {
            if ( seems_utf8( $str ) == false ) {
                $str = utf8_encode( $str );
            }
            
            $str = "<![CDATA[$str" . ( ( substr( $str, -1 ) == ']' ) ? ' ' : '') . "]]>";
            return $str;
        }

        /**
         * Return the URL of the site
         * @since 2.5.0
         * @return string Site URL.
         */
        public static function wem_site_url() {
            // ms: the base url
            if ( is_multisite() ) {
                return network_home_url();
            } else {
                return get_bloginfo_rss( 'url' );
            }
        }

        /**
         * Output a term_name XML tag from a given term object
         *
         * @since 2.9.0
         *
         * @param object $term Term Object
         */
        public static function wem_term_name( $term ) {
            if ( empty( $term->name ) )
                return;
        
            echo '<wp:term_name>' . self::wem_cdata( $term->name ) . '</wp:term_name>';
        }

        /**
         * Ouput all navigation menu terms
         *
         * @since 3.1.0
         */
        public static function wem_nav_menu_terms() {
            $nav_menus = wp_get_nav_menus();
            if ( empty( $nav_menus ) || ! is_array( $nav_menus ) )
                return;
        
            foreach ( $nav_menus as $menu ) {
                echo "\t<wp:term><wp:term_id>{$menu->term_id}</wp:term_id><wp:term_taxonomy>nav_menu</wp:term_taxonomy><wp:term_slug>{$menu->slug}</wp:term_slug>";
                self::wem_term_name( $menu );
                echo "</wp:term>\n";
            }
        }
    
        public static function wem_nav_menu_item_terms_and_posts( &$post_ids ) {
            $posts_to_add = array();
            foreach( $post_ids as $post_id ) {
                if( ($type = get_post_meta( $post_id, '_menu_item_type', true ) ) == 'taxonomy' ) {
                    $term = get_term( get_post_meta( $post_id, '_menu_item_object_id', true ), ($tax = get_post_meta( $post_id, '_menu_item_object', true )) );
                    echo "\t<wp:term><wp:term_id>{$term->term_id}</wp:term_id><wp:term_taxonomy>{$tax}</wp:term_taxonomy><wp:term_slug>{$term->slug}</wp:term_slug>";
                    self::wem_term_name( $term );
                    echo "</wp:term>\n";
                } elseif( $type == 'post_type' && in_array( get_post_meta( $post_id, '_menu_item_object', true ), array( 'post', 'page', 'product' ) ) ) {
                    $posts_to_add[] = get_post_meta( $post_id, '_menu_item_object_id', true );
                }
            }
            $post_ids = array_merge( $posts_to_add, $post_ids );
        }

        /**
         * Output list of taxonomy terms, in XML tag format, associated with a post
         *
         * @since 2.3.0
         */
        public static function wem_post_taxonomy() {
            global $post;
            $taxonomies = get_object_taxonomies( $post->post_type );
            if ( empty( $taxonomies ) ) {
                return;
            }
            
            $terms = wp_get_object_terms( $post->ID, $taxonomies );
            foreach ( (array) $terms as $term ) {
                echo "\t\t<category domain=\"{$term->taxonomy}\" nicename=\"{$term->slug}\">" . self::wem_cdata( $term->name ) . "</category>\n";
            }
        }
    }
    $WP_Export_Menus = new WP_Export_Menus();
}