<?php
class WP_Export_Taxonomies {
    public function __construct() {
        add_action('export_filters', [$this, 'export_filters']);
        add_filter('export_args', [$this, 'export_args']);
        add_action('admin_head', [$this, 'export_js']);
    }

    public function export_filters() {
        echo '<p><label><input type="radio" name="content" value="taxonomy" /> Taxonomies</label></p>';
    }

    public function export_args($args) {
        if (!isset($_GET['download']) || $_GET['content'] !== 'taxonomy') {
            return $args;
        }
        $this->wp_export_taxonomies();
        exit;
    }

    public function wp_export_taxonomies() {
        $filename = 'wordpress-taxonomies.' . date('Y-m-d') . '.xml';

        header('Content-Description: File Transfer');
        header('Content-Disposition: attachment; filename=' . $filename);
        header('Content-Type: text/xml; charset=' . get_option('blog_charset'), true);

        echo "<?xml version=\"1.0\" encoding=\"" . get_bloginfo('charset') . "\" ?>\n";
        echo '<rss version="2.0" xmlns:wp="http://wordpress.org/export/1.1/">' . "\n";
        echo "<channel>\n";
        echo "<title>" . get_bloginfo_rss('name') . "</title>\n";
        echo "<link>" . get_bloginfo_rss('url') . "</link>\n";
        echo "<description>" . get_bloginfo_rss('description') . "</description>\n";
        echo "<pubDate>" . date('D, d M Y H:i:s +0000') . "</pubDate>\n";
        echo "<language>" . get_option('rss_language') . "</language>\n";
        echo "<wp:wxr_version>1.1</wp:wxr_version>\n";
        echo "<wp:base_site_url>" . esc_url(get_site_url()) . "</wp:base_site_url>\n";
        echo "<wp:base_blog_url>" . esc_url(get_bloginfo_rss('url')) . "</wp:base_blog_url>\n";

        $taxonomies = get_taxonomies(['public' => true], 'objects');

        foreach ($taxonomies as $taxonomy) {
            $terms = get_terms([
                'taxonomy' => $taxonomy->name,
                'hide_empty' => false,
            ]);

            foreach ($terms as $term) {
                echo "<wp:term>\n";
                echo "\t<wp:term_id>{$term->term_id}</wp:term_id>\n";
                echo "\t<wp:term_taxonomy>{$term->taxonomy}</wp:term_taxonomy>\n";
                echo "\t<wp:term_slug>{$term->slug}</wp:term_slug>\n";
                echo "\t<wp:term_name><![CDATA[{$term->name}]]></wp:term_name>\n";
                echo "\t<wp:term_description><![CDATA[{$term->description}]]></wp:term_description>\n";
                echo "\t<wp:term_parent>{$term->parent}</wp:term_parent>\n";
                echo "</wp:term>\n";
            }
        }

        echo "</channel>\n";
        echo "</rss>\n";
    }

    public function export_js() {
        echo "<script>jQuery(function($){ $('input[name=content]').change(function(){}); });</script>";
    }
}

new WP_Export_Taxonomies();
