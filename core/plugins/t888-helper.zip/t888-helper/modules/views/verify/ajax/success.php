<div class="vr-message message-success">
    <p><strong><?= esc_html__('Successful activation!', 't888-helper') ?></strong></p>
    <p><strong><?= esc_html__('Your Information:', 't888-helper') ?></strong></p>
<p><strong><?= esc_html__('Item name: ', 't888-helper')   ?></strong><?= esc_html($item_name) ?></p>
<p><strong><?= esc_html__('Item ID: ', 't888-helper')     ?></strong><?= esc_html($item_id) ?></p>
<p><strong><?= esc_html__('Sold at: ', 't888-helper')     ?></strong><?= esc_html($created_at) ?></p>
<p><strong><?= esc_html__('Buyer: ', 't888-helper')       ?></strong><?= esc_html($buyer) ?></p>
<p><strong><?= esc_html__('License: ', 't888-helper')     ?></strong><?= esc_html($licence) ?></p>
<p><strong><?= esc_html__('Supported until: ', 't888-helper') ?></strong><?= esc_html($supported_until) ?></p>
<p>
    <?php esc_html_e('Return to the Dashboard and install required plugins', 't888-helper') ?>
    <a href="<?php echo esc_url(get_dashboard_url()) ?>"><?php esc_html_e("Return to the Dashboard", "t888-helper") ?></a>
</p>
<p>
    <?php esc_html_e('Go to our forum to create your topic if you have any problem with our theme', 't888-helper') ?>
    <a href="<?php echo esc_url('http://7uptheme.net') ?>"><?php esc_html_e("7upTheme", "t888-helper") ?></a>
</p>
</div>