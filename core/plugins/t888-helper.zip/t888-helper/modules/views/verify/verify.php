<div class="wrap">
    <h2><?php esc_html_e('Verify Purchase Code','t888-helper') ?></h2>
</div>
<?php 
$checkvr = VerifyPurchaseController::_check_verify();
if(!$checkvr) $ms_class = 'd-block';
else $ms_class = 'd-hidden';
?>
<p id="message" class="vr-message message-info <?php echo esc_attr($ms_class)?>">
    <strong><?php esc_html_e('Please activate your theme to enable premium features.','t888-helper') ?></strong>
</p>
<form id="theme_verify_form">
	<?php
	$code_to_verify = get_option('user_purchase_code','');
    $envato_name = get_option('user_envato_name','');
	?>
	<p><?php esc_html_e('Your Envato username*','t888-helper') ?></p>
	<p><input class="regular-text" required name="user_envato_name" value="<?php echo esc_attr($envato_name)?>"></p>
	<p><?php esc_html_e('Your Purchase code*','t888-helper') ?></p>
	<p><input type="password" required class="regular-text" name="user_purchase_code" value="<?php echo esc_attr($code_to_verify)?>"></p>
	<p class="submit">
		<button type="submit" href="#" class="button button-primary check-verify"><?php esc_html_e("Save Changes","t888-helper")?></button>
	</p>
</form>
<div id="check-result">
	<?php
	$theme = wp_get_theme();
	if($checkvr){
		echo '<div class="vr-message message-success">';
		echo 	'<p><strong>'.esc_html__('Successful activation!','t888-helper').'</strong></p>';
		echo 	'<p><strong>'.esc_html__('Your Information:','t888-helper').'</strong></p>';
		$data = VerifyPurchaseController::_get_verify_data($code_to_verify);
		if(isset($data['buyer'])){
			echo 	'<p><strong>'.esc_html__('Item name: ','t888-helper').'</strong>'.$data['item_name'].'</p>';
			echo 	'<p><strong>'.esc_html__('Item ID: ','t888-helper').'</strong>'.$data['item_id'].'</p>';
			echo 	'<p><strong>'.esc_html__('Created at: ','t888-helper').'</strong>'.$data['created_at'].'</p>';
			echo 	'<p><strong>'.esc_html__('Buyer: ','t888-helper').'</strong>'.$data['buyer'].'</p>';
			echo 	'<p><strong>'.esc_html__('Licence: ','t888-helper').'</strong>'.$data['licence'].'</p>';
			echo 	'<p><strong>'.esc_html__('Supported until: ','t888-helper').'</strong>'.$data['supported_until'].'</p>';
		}
		echo 	'<p>
					'.esc_html__('Go to our website to create your topic if you have any problem with our theme','t888-helper').'
					<a href="'.esc_url('http://web888.vn/').$theme->get( 'TextDomain' ).'">'.esc_html__("Tech888 Group","t888-helper").'</a>
				</p>';
		echo '</div>';
	}
	else{
		if($code_to_verify == '' && $envato_name == '') echo '<p class="vr-message message-error">'.esc_html__('Your current theme has not been activated. Please enter the information and activate to start using our products.','t888-helper').'</p>';
		else echo '<p class="vr-message message-error">'.esc_html__('Your Invalid information!. Please recheck envato username or purchase code','t888-helper').'</p>';
	}
	?>
</div>
<!-- <style>
#verify-notice{
	display: none;
}
</style> -->