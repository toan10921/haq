<div class="container">
    <h2><?php esc_html_e("Bulk Import Sample Data", "t888-helper"); ?></h2>
    <p><?php esc_html_e("Import Sample data for theme initialize", "t888-helper"); ?></p>
    <div class="message"><?php esc_html_e("Note: This functionality is only available for development.", "t888-helper"); ?></div>
</div>
<div class="container">
    <div class="t888-row">
        <div class="t888-col t888-col-12">
            <form method="post" id="import_sample_data" action="">
                <input type="hidden" name="action" value="import_sample_data">
            
                <div class="form-group action-type">
                    <div class="form-label">
                        <label><?php esc_html_e('Action Create/Update', 't888-helper') ?></label>
                    </div>
                    <div class="form-input">
                        <select name="action_type" id="action_type" class="form-control">
                            <option value="create" selected><?php esc_html_e('Create', 't888-helper'); ?></option>
                            <option value="update"><?php esc_html_e('Update', 't888-helper'); ?></option>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <div class="form-label">
                        <label><?php esc_html_e('Choose Post Type', 't888-helper') ?></label>
                    </div>
                    <div class="form-input">
                        <select name="post_type" id="post_type" class="form-control">
                            <option value="post" selected><?php esc_html_e('Post', 't888-helper'); ?></option>
                            <option value="product"><?php esc_html_e('Product', 't888-helper'); ?></option>
                            <option value="page"><?php esc_html_e('Page', 't888-helper'); ?></option>
                        </select>
                    </div>
                </div>
                <div class="create-fields-wrapper p-10">
                    <div class="form-group">
                        <div class="form-label">Categories</div>
                        <div class="form-input">
                            <select name="cats[]" multiple="true">
                                <?php
                                $categories = get_categories(array('hide_empty' => false));
                                foreach ($categories as $category) {
                                    echo '<option value="' . esc_attr($category->term_id) . '">' . esc_html($category->name) . '</option>';
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-label">
                            <label><?php esc_html_e('List titles', 't888-helper') ?></label>
                            <p><?php esc_html_e('Enter the titles you want to create.', 't888-helper'); ?></p>
                            <button type="button" class="button button-secondary" id="add_more_title">
                                <?php esc_html_e('Add more title', 't888-helper'); ?>
                            </button>
                        </div>
                        <div class="form-input">
                            <input name="titles[]" class="form-control" rows="5" placeholder="<?php esc_html_e('Enter title', 't888-helper'); ?>" />
                            <button type="button" class="button button-secondary remove-title btn-remove">x</button>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-label">
                            <label for="excerpt"><?php esc_html_e('Excerpt', 't888-helper') ?></label>
                        </div>
                        <div class="form-label">
                            <p><?php esc_html_e('Enter the excerpt you want to create, allow raw html', 't888-helper'); ?></p>
                            <button type="button" class="button button-secondary" id="add_more_excerpt">
                                <?php esc_html_e('Add more excerpt', 't888-helper'); ?>
                            </button>
                        </div>
                        <div class="form-input">
                            <textarea name="excerpt[]" class="form-control" rows="5" placeholder="<?php esc_html_e('Enter excerpt values, allow raw html', 't888-helper'); ?>"></textarea>
                            <button type="button" class="button button-secondary remove-excerpt btn-remove">x</button>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-label">
                            <label><?php esc_html_e('Content values', 't888-helper') ?></label>
                            <p><?php esc_html_e('Enter the content you want to create, allow raw html.', 't888-helper'); ?></p>
                            <button type="button" class="button button-secondary" id="add_more_content"><?php esc_html_e('Add more content', 't888-helper'); ?></button>
                        </div>
                        <div class="form-input">
                            <textarea name="content[]" class="form-control" rows="5" placeholder="<?php esc_html_e('Enter content values separated by line breaks', 't888-helper'); ?>"></textarea>
                            <button type="button" class="button button-secondary remove-content btn-remove">x</button>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="form-label">
                            <label><?php esc_html_e('Number of posts to create', 't888-helper') ?></label>
                        </div>
                        <div class="form-input">
                            <input type="number" name="post_count" id="post_count" class="form-control" value="30" min="1">
                        </div>
                    </div>
                </div>
                <div class="update-fields-wrapper p-10">
                    <div class="form-group field-type-update">
                        <div class="form-label">
                            <label><?php esc_html_e('Field type for update', 't888-helper') ?></label>
                        </div>
                        <div class="form-input">
                            <select name="field_type" id="field_type" class="form-control">
                                <option value="thumbnail"><?php esc_html_e('Feature Thumbnail', 't888-helper'); ?></option>
                                <option value="thumb_hover" selected><?php esc_html_e('Thumbnail for hover (Only for Product Post Type)', 't888-helper'); ?></option>
                                <option value="gallery"><?php esc_html_e('Gallery', 't888-helper'); ?></option>
                                <option value="cats"><?php esc_html_e('Categories', 't888-helperhelper'); ?></option>
                                <option value="tags"><?php esc_html_e('Tags', 't888-helperhelper'); ?></option>
                                <option value="excerpt"><?php esc_html_e('Excerpt', 't888-helperhelper'); ?></option>
                                <option value="content"><?php esc_html_e('Content', 't888-helperhelper'); ?></option>
                                <option value="title"><?php esc_html_e('Title', 't888-helperhelper'); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group thumbnail-value">
                        <div class="form-label">
                            <label><?php esc_html_e('List thumbnail values', 't888-helperhelper') ?></label>
                            <p><?php esc_html_e('Enter the thumbnail id values you want to import, separated by commas. Example: 123, 456, 789', 't888-helperhelper'); ?></p>
                        </div>
                        <div class="form-input">
                            <textarea name="thumbnails_value" id="thumbnails_value" class="form-control" rows="5" placeholder="<?php esc_html_e('Enter thumbnail values separated by commas', 't888-helperhelper'); ?>"></textarea>
                        </div>
                    </div>
                    <div class="form-group thumb_hover-value">
                        <div class="form-label">
                            <label><?php esc_html_e('List thumbnail hover values', 't888-helperhelper') ?></label>
                            <p><?php esc_html_e('Enter the thumbnail hover id values you want to import, separated by commas. Example: 123, 456, 789', 't888-helperhelper'); ?></p>
                        </div>
                        <div class="form-input">
                            <textarea name="thumbs_hover_value" id="thumbs_hover_value" class="form-control" rows="5" placeholder="<?php esc_html_e('Enter thumbnail hover values separated by commas', 't888-helperhelper'); ?>"></textarea>
                        </div>
                    </div>
                    <div class="form-group gallery-value">
                        <div class="form-label">
                            <label><?php esc_html_e('List gallery values', 't888-helperhelper') ?></label>
                            <p><?php esc_html_e('Enter the gallery id values you want to import, separated by commas. Example: 123, 456, 789', 't888-helperhelper'); ?></p>
                        </div>
                        <div class="form-input">
                            <textarea name="gallery_value" id="gallery_value" class="form-control" rows="5" placeholder="<?php esc_html_e('Enter gallery values separated by commas', 't888-helperhelper'); ?>"></textarea>
                        </div>
                    </div>
                    <div class="form-group cats-value">
                        <div class="form-label">
                            <label><?php esc_html_e('List categories', 't888-helperhelper') ?></label>
                            <p><?php esc_html_e('Enter the category IDs you want to import, separated by commas. Example: 123, 456, 789', 't888-helperhelper'); ?></p>
                        </div>
                        <div class="form-input">
                            <textarea name="cats_value" id="cats_value" class="form-control" rows="5" placeholder="<?php esc_html_e('Enter category IDs separated by commas', 't888-helperhelper'); ?>"></textarea>
                        </div>
                    </div>
                    <div class="form-group tags-value">
                        <div class="form-label">
                            <label><?php esc_html_e('List tags', 't888-helperhelper') ?></label>
                            <p><?php esc_html_e('Enter the tag IDs you want to import, separated by commas. Example: 123, 456, 789', 't888-helperhelper'); ?></p>
                        </div>
                        <div class="form-input">
                            <textarea name="tags_value" id="tags_value" class="form-control" rows="5" placeholder="<?php esc_html_e('Enter tag IDs separated by commas', 't888-helperhelper'); ?>"></textarea>
                        </div>
                    </div>
                    <div class="form-group excerpt-value">
                        <div class="form-label">
                            <label><?php esc_html_e('Excerpt', 't888-helperhelper') ?></label>
                            <p><?php esc_html_e('Enter the excerpt you want to import (raw html). Excerpt will be applied to all products/posts.', 't888-helperhelper'); ?></p>
                        </div>
                        <div class="form-input">
                            <textarea name="excerpt_value" id="excerpt_value" class="form-control" rows="5" placeholder="<?php esc_html_e('Enter excerpt', 't888-helperhelper'); ?>"></textarea>
                        </div>
                    </div>
                    <div class="form-group content-value">
                        <div class="form-label">
                            <label><?php esc_html_e('Content', 't888-helperhelper') ?></label>
                            <p><?php esc_html_e('Enter the content you want to import (raw html). Content will be applied to all products/posts.', 't888-helperhelper'); ?></p>
                        </div>
                        <div class="form-input">
                            <textarea name="content_value" id="content_value" class="form-control" rows="5" placeholder="<?php esc_html_e('Enter content', 't888-helperhelper'); ?>"></textarea>
                        </div>
                    </div>
                    <div class="form-group title-value">
                        <div class="form-label">
                            <label><?php esc_html_e('Title', 't888-helperhelper') ?></label>
                            <p><?php esc_html_e('Enter the title you want to import. Title will be applied to all products/posts.', 't888-helperhelper'); ?></p>
                        </div>
                        <div class="form-input">
                            <textarea name="title_value" id="title_value" class="form-control" rows="5" placeholder="<?php esc_html_e('Enter title', 't888-helperhelper'); ?>"></textarea>
                        </div>
                    </div>
                    <div class="form-group exclude-posts-id-values">
                        <div class="form-label">
                            <label><?php esc_html_e('Exclude Post ID', 't888-helperhelper') ?></label>
                            <p><?php esc_html_e('Enter the post ID you want to exclude, separate by comma (,).', 't888-helperhelper'); ?></p>
                        </div>
                        <div class="form-input">
                            <input type="text" name="post_ids_exclude" id="post_ids_exclude" class="form-control" placeholder="<?php esc_html_e('Enter post IDs', 't888-helperhelper'); ?>" />
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <button type="submit" class="button button-primary" id="import_sample_data_btn">
                        <?php esc_html_e('Import Sample Data', 't888-helperhelper'); ?>
                    </button>
                </div>
            </form>
        </div>

    </div>
</div>