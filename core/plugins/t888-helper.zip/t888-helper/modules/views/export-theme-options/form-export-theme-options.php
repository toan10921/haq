<div class="container">
    <h1 class="title"><?php esc_html_e('Export Theme Options', 't888-helper'); ?></h1>
    <p><?php esc_html_e('Export theme options to file', 't888-helper'); ?></p>
    <form method="post" id="export_theme_options_form" action="">
        <input type="hidden" name="action" value="export_theme_options">
       <?php
// đảm bảo là mảng để serialize cho đúng
$theme_options = isset($theme_options) && is_array($theme_options) ? $theme_options : [];
$payload = base64_encode(serialize($theme_options));
?>
<textarea name="theme_options" id="theme_options" class="form-control" rows="10"><?php
    echo esc_textarea($payload);
?></textarea>

        <div class="form-group">
            <div class="form-label">
                <span class="submit-btn"><input type="submit" id="export-theme-options" class="button button-primary button-large" value="Export Theme Options"></span>
            </div>
        </div>
    </form>
</div>