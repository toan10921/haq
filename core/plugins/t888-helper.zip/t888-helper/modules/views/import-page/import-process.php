<div class="container">
    <h1 class="title"><?php esc_html_e("Importing Demo", "t888-helper"); ?></h1>
    <p><?php esc_html_e("Please wait while we import the demo content.", "t888-helper"); ?></p>
</div>
<div class="container">
    <h2><?php esc_html_e('Choose Data Import', 't888-helper'); ?></h2>
    <form action="" method="post" id="start-import-form">
        <input type="hidden" name="action" value="start_import">
        <div class="data-import">
            <div class="box-media form-group">
                <input type="checkbox" value="import_media" id="import_media" name="import_media" checked />
                <label for="import_media"><?php esc_html_e("Media Attachments", "t888-helper"); ?></label>
            </div>
            <div class="box-content form-group">
                <input type="checkbox" value="import_content" id="import_content" name="import_content" checked />
                <label for="import_content"><?php esc_html_e("Content", "t888-helper"); ?></label>
            </div>
            <div class="box-theme-options form-group">
                <input type="checkbox" value="theme_options" id="import_theme_options" name="import_theme_options" checked />
                <label for="import_theme_options"><?php esc_html_e("Theme Options", "t888-helper"); ?></label>
            </div>
            <div class="box-widgets form-group">
                <input type="checkbox" value="import_widgets" id="import_widgets" name="import_widgets" checked />
                <label for="import_widgets"><?php esc_html_e("Widgets", "t888-helper"); ?></label>
            </div>
            <div class="box-settings form-group">
                <input type="checkbox" value="import_settings" id="import_settings" name="import_settings" checked />
                <label for="import_settings"><?php esc_html_e("Settings", "t888-helper"); ?></label>
            </div>
            <div class="box-settings form-group">
                <input type="checkbox" value="import_menu" id="import_menus" name="import_menus" checked />
                <label for="import_menus"><?php esc_html_e("Menus", "t888-helper"); ?></label>
            </div>
            <div class="box-revolution-slider form-group">
                <input type="checkbox" value="import_revolution_slider" id="import_revolution_slider" name="import_revolution_slider" checked />
                <label for="import_revolution_slider"><?php esc_html_e("Revolution Slider", "t888-helper"); ?></label>
                <small class="description"><?php esc_html_e("Import Revolution Slider data from theme directory (core/import/data/revolution-slider)", "t888-helper"); ?></small>
            </div>
            <div class="box-elementor-kit form-group">
                <input type="checkbox" value="import_elementor_kit" id="import_elementor_kit" name="import_elementor_kit" checked />
                <label for="import_elementor_kit"><?php esc_html_e("Elementor Kit", "t888-helper"); ?></label>
                <small class="description"><?php esc_html_e("Import Elementor Kit from theme directory (core/import/data/elementor-kit/elementor-kit.zip)", "t888-helper"); ?></small>
            </div>
            <div class="form-group">
                <label>Import Media Options</label>
                <select name="import_media_option" id="import_media_option">
                     <option value="fetch" selected><?php esc_html_e("Fetch media from demo", "t888-helper"); ?></option>
                    <option value="local" ><?php esc_html_e("Do not import media", "t888-helper"); ?></option>
                </select>
            </div>
        </div>
        <br />
        <br />
        <button id="import-demo" class="btn button" type="submit">Import</button>
    </form>
    <pre id="import-messages"></pre>
</div>