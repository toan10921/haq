<div class="container">
    <h2><?php esc_html_e("Import a Demo", "t888-helper"); ?></h2>
    <p><?php esc_html_e("Choose a pre-built website for starting a quick design process.", "t888-helper"); ?></p>
    <div class="message"><?php esc_html_e("Note: Make sure to activate required plugins prior to import a demo.", "t888-helper"); ?></div>
</div>
<div class="container">
    <div class="t888-row">
        <div class="t888-col t888-col-4">
            <figure class="t888-image">
                <img src="<?php echo get_template_directory_uri() . '/screenshot.png'; ?>" alt="<?php esc_html_e('Black & Beans', 't888-helper') ?>">
                <div class="t888-overlay"></div>
                <div class="t888-btn-group">
                    <a href="<?php echo esc_url(admin_url('themes.php?page=import-page&view=import_process')); ?>" id="import-id" data-import-id="0" data-demo-id="<?php echo esc_html('t888-helper') ?>" class="t888-btn t888-popup-import">
                        <span>Import Demo</span>
                    </a><br>
                    <a target="_blank" href="#" class="t888-preview-btn">
                        <span>Preview Demo</span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-external-link">
                            <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                            <polyline points="15 3 21 3 21 9"></polyline>
                            <line x1="10" y1="14" x2="21" y2="3"></line>
                        </svg>
                    </a>
                </div>
            </figure>
        </div>
        <div class="t888-col t888-col-4">
        </div>
        <div class="t888-col t888-col-4">
        </div>

    </div>
</div>