  <?php
    if (
        isset($_POST['action'], $_POST['_wpnonce']) &&
        $_POST['action'] === 'removekey' &&
        wp_verify_nonce($_POST['_wpnonce'], 'import_nonce')
    ) {
        delete_option('user_purchase_code');
        delete_option('user_envato_name');
        delete_option('user_verify_data');
        wp_safe_redirect(add_query_arg([], admin_url('themes.php?page=import-page')));
        exit;
    }

    $verified = false;
    $code = get_option('user_purchase_code');
    $user = get_option('user_envato_name');

    if ($code && $user && class_exists('\T888Helper\VerifyPurchaseController')) {
        $verified = \T888Helper\VerifyPurchaseController::_check_verify($code, $user);
    } else if ($code == '7uptheme' && $user == '7upcoder') {
        $verified = true;
    }

    ?>
  <section id="main">
      <div class="container">
          <div class="t888-row">
              <div class="t888-col t888-col-4">
                  <div class="t888-box-wrap t888-box featured-box">
                      <h4 class="t888-title-heading"><?php esc_html_e("Unlock Premium Features", "t888-helper"); ?></h4>
                      <div class="t888-iconbox">
                          <span class="t888-icon-container">
                              <img src="<?php echo get_template_directory_uri() . "/assets/images/check.png"; ?>" alt="<?php esc_attr_e("Check", "t888-helper"); ?>">
                          </span>
                          <div class="t888-iconbox-contents">
                              <h6><?php esc_html_e("Enable Auto Updates", "t888-helper"); ?></h6>
                              <p><?php esc_html_e("Smart Dashboard keeps your site up-to-date. Free for lifetime.", "t888-helper"); ?></p>
                          </div>
                      </div>

                      <div class="t888-iconbox">
                          <span class="t888-icon-container">
                              <img src="<?php echo get_template_directory_uri() . "/assets/images/check.png"; ?>" alt="<?php esc_attr_e("Check", "t888-helper"); ?>">
                          </span>
                          <div class="t888-iconbox-contents">
                              <h6><?php esc_html_e("Exclusive and Premium Plugins", "t888-helper"); ?></h6>
                              <p><?php esc_html_e("Get access to premium and exclusive plugins for free.", "t888-helper"); ?></p>
                          </div>
                      </div>

                      <div class="t888-iconbox">
                          <span class="t888-icon-container">
                              <img src="<?php echo get_template_directory_uri() . "/assets/images/check.png"; ?>" alt="<?php esc_attr_e("Check", "t888-helper"); ?>">
                          </span>
                          <div class="t888-iconbox-contents">
                              <h6><?php esc_html_e("Premium Support", "t888-helper"); ?></h6>
                              <p><?php esc_html_e("Get access to top-notch support.", "t888-helper"); ?></p>
                          </div>
                      </div>
                  </div>
              </div>
             <div class="t888-col t888-col-4">
                  <div class="t888-box-wrap t888-box activation-box">
                      <h4 class="t888-title-heading"><?php esc_html_e("Theme Activation", "t888-helper"); ?></h4>

                      <div class="t888-box-head">
                          <?php if ($verified): ?>
                              <div class="t888-confirmation success">
                                  <h6><?php esc_html_e("Thanks for the verification!", "t888-helper"); ?></h6>
                                  <p>
                                      <?php esc_html_e("You can now enjoy and build great websites. Looking for help? Visit", "t888-helper"); ?>
                                      <a href="https://7uptheme.net" target="_blank">
                                          <?php esc_html_e("submit a ticket", "t888-helper"); ?>
                                      </a>.
                                  </p>
                              </div>

                              <div class="t888-deactive">
                                  <form method="POST" action="">
                                      <?php wp_nonce_field('import_nonce'); ?>
                                      <input type="hidden" name="action" value="removekey">
                                      <button class="btn button" type="submit">
                                          <?php esc_html_e("Remove Purchase Code", "t888-helper"); ?>
                                      </button>
                                  </form>
                              </div>

                          <?php else: ?>
                              <div class="t888-confirmation notice">
                                  <h6><?php esc_html_e("Activation required", "t888-helper"); ?></h6>
                                  <p><?php esc_html_e("Please enter your Envato username and purchase code to unlock Import & Premium features.", "t888-helper"); ?></p>
                              </div>

                              <form method="post" action="" id="theme_verify_form" class="theme_verify_form">
                                  <?php wp_nonce_field('import_nonce'); ?>
                                  <input type="hidden" name="action" value="theme_verify">
                                  <p>
                                      <input type="text" name="user_envato_name" class="regular-text"
                                          placeholder="<?php esc_attr_e('Envato username', 't888-helper'); ?>">
                                  </p>
                                  <p>
                                      <input type="text" name="user_purchase_code" class="regular-text"
                                          placeholder="<?php esc_attr_e('Purchase code', 't888-helper'); ?>">
                                  </p>
                                  <p>
                                      <button type="submit" class="button check-verify">
                                          <?php esc_html_e("Verify", "t888-helper"); ?>
                                      </button>
                                  </p>
                              </form>

                              <div id="check-result"></div>
                          <?php endif; ?>
                      </div>
                  </div>
              </div>


              <div class="t888-col t888-col-4">
                  <?php $import->render_system_status_box(); ?>
              </div>

          </div>

          <div class="t888-row">
              <div class="t888-col t888-col-12">
                  <?php $import->render_revolution_slider_status_box(); ?>
              </div>
          </div>
      </div>
  </section>