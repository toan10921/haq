<div class="container">
    <h1 class="title"><?php esc_html_e('Export Settings', 't888-helper'); ?></h1>
    <p><?php esc_html_e('Export settings to json file', 't888-helper'); ?></p>
    <form method="post" id="export_settings_form" action="">
        <input type="hidden" name="action" value="export_settings">
        <div class="form-group">
            <div class="form-label">
                <label><?php esc_html_e('Show on Front', 't888-helper') ?></label>
            </div>
            <div class="form-input">
                <select name="show_on_front" id="show_on_front" class="form-control">
                    <option value="posts" <?php selected($show_on_front, 'posts'); ?>><?php esc_html_e('Your latest posts', 't888-helper'); ?></option>
                    <option value="page" <?php selected($show_on_front, 'page'); ?>><?php esc_html_e('A static page', 't888-helper'); ?></option>
                </select>
            </div>
        </div>
        <div class="form-group">
            <div class="form-label">
                <label><?php esc_html_e('Home Page', 't888-helper') ?></label>
            </div>
            <div class="form-input">
                <input type="text" name="page_on_front" id="page_on_front" class="form-control" value="<?php echo esc_html($page_on_front); ?>">
            </div>
        </div>
        <div class="form-group">
            <div class="form-label">
                <label><?php esc_html_e('Page for posts', 't888-helper') ?></label>
            </div>
            <div class="form-input">
                <input type="text" name="page_for_posts" id="page_for_posts" class="form-control" value="<?php echo esc_html($page_for_posts); ?>">
            </div>
        </div>
        <div class="form-group">
            <div class="form-label">
                <label><?php esc_html_e('Date format', 't888-helper') ?></label>
            </div>
            <div class="form-input">
                <input type="text" name="date_format" id="date_format" class="form-control" value="<?php echo esc_html($date_format); ?>">
            </div>
        </div>
        <div class="form-group">
            <div class="form-label">
                <label><?php esc_html_e('Time format', 't888-helper') ?></label>
            </div>
            <div class="form-input">
                <input type="text" name="time_format" id="time_format" class="form-control" value="<?php echo esc_html($time_format); ?>">
            </div>
        </div>
        <div class="form-group">
            <div class="form-label">
                <label><?php esc_html_e('Posts Per Page', 't888-helper') ?></label>
            </div>
            <div class="form-input">
                <input type="number" name="posts_per_page" id="posts_per_page" class="form-control" value="<?php echo esc_html($posts_per_page); ?>">
            </div>
        </div>
        <div class="form-group">
            <div class="form-label">
                <label><?php esc_html_e('Permalink Structure', 't888-helper') ?></label>
            </div>
            <div class="form-input">
                <input type="text" name="permalink_structure" id="permalink_structure" class="form-control" value="<?php echo esc_html($permalink_structure); ?>">
            </div>
        </div>
        <div class="form-group">
            <div class="form-label">
                <label><?php esc_html_e('Shop Page', 't888-helper') ?></label>
            </div>
            <div class="form-input">
                <input type="text" name="woocommerce_shop_page" id="woocommerce_shop_page" class="form-control" value="<?php echo esc_html($woocommerce_shop_page); ?>">
            </div>
        </div>
        <div class="form-group">
            <div class="form-label">
                <label><?php esc_html_e('Cart Page', 't888-helper') ?></label>
            </div>
            <div class="form-input">
                <input type="text" name="woocommerce_cart_page" id="woocommerce_cart_page" class="form-control" value="<?php echo esc_html($woocommerce_cart_page); ?>">
            </div>
        </div>
        <div class="form-group">
            <div class="form-label">
                <label><?php esc_html_e('Checkout Page', 't888-helper') ?></label>
            </div>
            <div class="form-input">
                <input type="text" name="woocommerce_checkout_page" id="woocommerce_checkout_page" class="form-control" value="<?php echo esc_html($woocommerce_checkout_page); ?>">
            </div>
        </div>
        <div class="form-group">
            <div class="form-label">
                <label><?php esc_html_e('My Account Page', 't888-helper') ?></label>
            </div>
            <div class="form-input">
                <input type="text" name="woocommerce_myaccount_page" id="woocommerce_myaccount_page" class="form-control" value="<?php echo esc_html($woocommerce_myaccount_page); ?>">
            </div>
        </div>
        <div class="form-group">
            <div class="form-label">
                <label><?php esc_html_e('Elementor CSS Print Method', 't888-helper') ?></label>
            </div>
            <div class="form-input">
                <select name="elementor_css_print_method" id="elementor_css_print_method" class="form-control">
                    <option value="external" <?php selected($elementor_css_print_method, 'external'); ?>>External File</option>
                    <option value="internal" <?php selected($elementor_css_print_method, 'internal'); ?>>Internal Embedding</option>
                    
                </select>
            </div>
        </div>
        <div class="form-group">
            <div class="form-label">
                <label><?php esc_html_e('Elementor CPT Support', 't888-helper') ?></label>
            </div>
            <div class="form-input">
                <?php
                 $enabled = (array) get_option('elementor_cpt_support', []);

$allow = [
  'post'              => 'Posts',
  'page'              => 'Pages',
  'product'           => 'Products',
  'elementor_library' => 'Elementor Templates',
  'mega_item'         => 'Mega Page',
  'header_item'       => 'Header Page',
  'footer_item'       => 'Footer Page',
];

foreach ($allow as $slug => $label) {
    if (!post_type_exists($slug)) continue; // CPT không có thì bỏ qua
    $checked = in_array($slug, $enabled, true) ? 'checked' : '';
    echo '<label style="display:block;margin-bottom:6px">';
    echo '<input type="checkbox" name="elementor_cpt_support[]" value="'.esc_attr($slug).'" '.$checked.'> ';
    echo esc_html($label).' <code>'.esc_html($slug).'</code>';
    echo '</label>';
}
                ?>
            </div>
        </div>
        <div class="form-group">
            <div class="form-label">
                <span class="submit-btn"><input type="submit" id="export-settings" class="button button-primary button-large" value="Export"></span>
            </div>
        </div>
    </form>
</div>