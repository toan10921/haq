<div class="container">
    <h1 class="title"><?php esc_html_e('Export Menu', 't888-helper'); ?></h1>
    <p><?php esc_html_e('Export menu to json file', 't888-helper'); ?></p>
    <form method="post" id="export_menu_form" action="">
        <input type="hidden" name="action" value="export_menus">
        <div class="form-group">
            <div class="form-label">
                <label><?php esc_html_e('Choose a menu to export', 't888-helper') ?></label>
            </div>
            <div class="form-input">
                <select name="menu" id="select-menu-to-export">
                    <option value="all">All Menus</option>
                    <?php
                    foreach ($menuModel->getListMenus() as $menu) {
                        echo "<option value='{$menu->term_id}'>{$menu->name}</option>";
                    }
                    ?>
                </select>
            </div>
        </div>
        <div class="form-group">
            <div class="form-label">
                <span class="submit-btn"><input type="submit" id="export-menus" class="button button-primary button-large" value="Export"></span>
            </div>
        </div>

    </form>
</div>