<div class="container">
    <h1 class="title"><?php esc_html_e('Export Widgets', 't888-helper'); ?></h1>
    <p><?php esc_html_e('Export widgets to file', 't888-helper'); ?></p>
    <form method="post" id="export_widgets_form" action="">
        <input type="hidden" name="action" value="export_widgets">
        <div class="form-group">
            <div class="form-label">
                <span class="submit-btn"><input type="submit" id="export-widgets" class="button button-primary button-large" value="Export Widgets"></span>
            </div>
        </div>
    </form>
</div>