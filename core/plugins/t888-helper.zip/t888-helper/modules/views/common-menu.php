<div class="container">
    <h1 class="title"><?php esc_html_e('Welcome to', 't888-helper'); ?> <?php echo wp_get_theme()->get('Name'); ?></h1>
    <p><?php esc_html_e('Theme Version:', 't888-helper'); ?> <?php echo wp_get_theme()->get('Version'); ?></p>
</div>
<div class="container">
    <div class="t888-menu">
        <ul class="t888-menu-left">
            <li class="is-active">
                <a href="<?php echo esc_url(admin_url('themes.php?page=import-page')); ?>">
                    <span><?php echo wp_get_theme()->get('Name'); ?> <?php esc_html_e("Dashboard", "t888-helper"); ?></span>
                </a>
            </li>
            <li class="">
                <a href="<?php echo esc_url(admin_url('themes.php?page=tgmpa-install-plugins&plugin_status=install')); ?>">

                    <span><?php esc_html_e("Install Plugins", "t888-helper") ?></span>
                </a>
            </li>
            <li class="">
                <?php
                if (!\T888Helper\VerifyPurchaseController::_check_verify()):
                ?>
                    <a href="<?php  echo esc_url(admin_url('themes.php?page=import-page')); ?>"><span><?php esc_html_e("Activate your license to Import Demo", "t888-helper") ?></span></a>
                <?php
                else:
                ?>
                    <a href="<?php echo esc_url(admin_url('themes.php?page=import-page&view=import')); ?>">
                        <span><?php esc_html_e("Import Demo", "t888-helper") ?></span>
                    </a>
                <?php
                endif;
                ?>

            </li>
        </ul>
        <ul class="t888-menu-right">
            <li>
                <a href="https://7uptheme.net" target="_blank">
                    <span><?php esc_html_e("Videos tutorial", "t888-helper"); ?></span>
                </a>
            </li>
            <li>
                <a href="https://7uptheme.net/support" target="_blank">
                    <span><?php esc_html_e("Support system", "t888-helper"); ?></span>
                </a>
            </li>
            <li>
                <a href="https://nebon.7uptheme.net" target="_blank">
                    <span><?php esc_html_e("Live Demo", "t888-helper"); ?></span>
                </a>
            </li>

            <li>
                <a href="https://7uptheme.net/docs" target="_blank">
                    <i class="t888-icn-ess icon-md-help-circle"></i>
                    <span><?php esc_html_e("Documentations", "t888-helper"); ?></span>
                </a>
            </li>
        </ul>
    </div>
</div>