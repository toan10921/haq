(($) => {
    $("#theme_verify_form").on("submit",  (e) => {
      e.preventDefault();
      var envato_name = $('input[name="user_envato_name"]').val();
      var user_purchase_code = $('input[name="user_purchase_code"]').val();
      var seft = $(this);
      seft.find('button.check-verify').append('<i class="fa fa-spinner fa-spin"></i>').attr('disabled', 'disabled');

      $.ajax({
        type: "POST",
        url: ajaxurl,
        crossDomain: true,
        data: {
          action: "purchase_code_verify",
          envato_name: envato_name,
          user_purchase_code: user_purchase_code,
        },
        success: function (data) {
          $("#check-result").html(data);
          if ($(".vr-message.message-success").length > 0)
            $("#message").fadeOut();
          else $("#message").fadeIn();
          seft.find("i").remove();
          seft.find('button.check-verify').removeAttr('disabled');
        },
        error: function (MLHttpRequest, textStatus, errorThrown) {
          console.log(errorThrown);
          alert('Please try again later');
          seft.find('button.check-verify').removeAttr('disabled');
        },
      });
    });
 
  })(jQuery);
  