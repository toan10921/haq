

jQuery(document).ready(function ($) {

    function handle_post_type_change() {
        $(document).on('change.post_type', '#import_sample_data #post_type', function () {
            let postType = $(this).val();
            $.ajax({
                url: import_page.ajax_url,
                type: 'POST',
                data: {
                    action: 'handle_post_type_change',
                    post_type: postType,
                    nonce: import_page.nonce
                },
                success: function (response) {
                    let categories = response.categories;
                    if (categories && categories.length > 0) {
                        let catsSelect = $('#import_sample_data select[name="cats[]"]');
                        catsSelect.html(categories.map(cat => `<option value="${cat.term_id}">${cat.name}</option>`).join(''));
                    } else {
                        $('#import_sample_data select[name="cats[]"]').html('<option value="0">No categories found</option>');
                    }
                }
            });
        });
    }

    function handle_change_field_type() {

        // disable all fields by default
        var lstClasses = ['thumbnail-value', 'thumb_hover-value', 'gallery-value', 'cats-value', 'tags-value', 'excerpt-value', 'content-value', 'title-value'];
        lstClasses.forEach(function (cls) {
            $('.' + cls).hide();
        });
        $('.thumb_hover-value').show(); // show thumbnail hover by default

        $(document).on('change.thumbnail_field', '#import_sample_data #field_type', function () {
            let fieldType = $(this).val();
            lstClasses.forEach(function (cls) {
                if (fieldType === cls.replace('-value', '')) {
                    $('.' + cls).show();
                } else {
                    $('.' + cls).hide();
                }
            });
        });
        var lstClassesUpdate = ['create-fields-wrapper', 'update-fields-wrapper'];
        lstClassesUpdate.forEach(function (cls) {
            $('.' + cls).hide();
        });

        $('.create-fields-wrapper').show(); // show create fields by default

        $(document).on('change.action_type', '#import_sample_data #action_type', function () {
            let actionType = $(this).val();
            if (actionType === 'update') {
                $('.' + lstClassesUpdate[1]).show();
                $('.' + lstClassesUpdate[0]).hide();
            } else {
                $('.' + lstClassesUpdate[1]).hide();
                $('.' + lstClassesUpdate[0]).show();
            }
        });


    }

    function handle_field_repeater() {
        $(document).on('click', '#add_more_excerpt', function (e) {
            e.preventDefault();
            let excerptField = $($('textarea[name="excerpt[]"]').get(0));
            let parentDiv = excerptField.parent();
            let newExcerptField = parentDiv.clone();
            newExcerptField.find('textarea').val('');
            newExcerptField.insertAfter(parentDiv);
        });

        $(document).on('click', '#add_more_content', function (e) {
            e.preventDefault();
            let contentField = $($('textarea[name="content[]"]').get(0));
            let parentDiv = contentField.parent();
            let newContentField = parentDiv.clone();
            newContentField.find('textarea').val('');
            newContentField.insertAfter(parentDiv);
        });

        $(document).on('click', '#add_more_title', function (e) {
            e.preventDefault();
            let titleField = $($('input[name="titles[]"]').get(0));
            let parentDiv = titleField.parent();
            let newTitleField = parentDiv.clone();
            newTitleField.find('input').val('');
            newTitleField.insertAfter(parentDiv);
        });

        $(document).on('click', '.remove-excerpt, .remove-content , .remove-title', function (e) {
            e.preventDefault();
            let parentDiv = $(this).closest('.form-input');
            if (parentDiv.siblings('.form-input').length > 0) {
                parentDiv.remove();
            } else {
                alert('You must have at least one excerpt field.');
            }
        });
    }

    // import demo data
    $('#start-import-form').on('submit', function (e) {
        e.preventDefault();

        const $form = $(this);
        const $btn = $form.find('#import-demo').prop('disabled', true);
        $('#import-messages').empty();


        const steps = [];
        if ($('#import_content').is(':checked')) steps.push('content');
        if ($('#import_menus').is(':checked')) steps.push('menus');
        if ($('#import_settings').is(':checked')) steps.push('settings');
        if ($('#import_widgets').is(':checked')) steps.push('widgets');
        if ($('#import_theme_options').is(':checked')) steps.push('theme_options');
        if ($('#import_revolution_slider').is(':checked')) steps.push('revolution_slider');
        if ($('#import_media').is(':checked')) steps.push('media');
        if ($('#import_elementor_kit').is(':checked')) steps.push('elementor_kit');
        steps.push('assign_menus_to_locations'); // always assign menus to locations

        if (!steps.length) {
            $('#import-messages').append('Nothing selected.\n');
            $btn.prop('disabled', false);
            return;
        }

        const base = {
            import_menus: $('#import_menus').is(':checked') ? 1 : 0,
            import_media: $('#import_media').is(':checked') ? 1 : 0,
            import_revolution_slider: $('#import_revolution_slider').is(':checked') ? 1 : 0,
            import_theme_options: $('#import_theme_options').is(':checked') ? 1 : 0,
            import_widgets: $('#import_widgets').is(':checked') ? 1 : 0,
            import_settings: $('#import_settings').is(':checked') ? 1 : 0,
            import_content: $('#import_content').is(':checked') ? 1 : 0,
            import_media_option: $('#import_media_option').val(),
            import_elementor_kit: $('#import_elementor_kit').is(':checked') ? 1 : 0,
            assign_menus_to_locations: 1,
            nonce: import_page.nonce
        };

        const $bar = $('.t888-progress__bar');
        const total = steps.length;
        const setProgress = (i) => { if ($bar.length) $bar.css('width', Math.round(i * 100 / total) + '%'); };
        setProgress(0);

        const run = (i) => {
            if (i >= total) {
                setProgress(total);
                $('#import-messages').append('All done!\n');
                $btn.prop('disabled', false);
                return;
            }
            const step = steps[i];

            $.ajax({
                url: import_page.ajax_url,
                type: 'POST',
                data: { action: 'start_import_step', step, ...base }
            }).done((resp) => {
                if (resp && resp.success) {
                    $('#import-messages').append('✓ ' + (resp.data.label || step) + ': ' + resp.data.message + "\n");
                    setProgress(i + 1);
                    run(i + 1);
                } else {
                    const msg = (resp && resp.data && resp.data.message) ? resp.data.message : 'Unknown error';
                    $('#import-messages').append('✗ ' + step + ': ' + msg + "\n");
                    $btn.prop('disabled', false);
                }
            }).fail((err) => {
                $('#import-messages').append('✗ ' + step + ': ' + (err.statusText || 'Request failed') + "\n");
                $btn.prop('disabled', false);
            });
        };

        run(0);
    });
    // export settings
    $('#export_menu_form, #export_settings_form, #export_widgets_form, #export_theme_options_form').on('submit', function (e) {
        e.preventDefault();
        let form = $(this);
        let data = form.serialize();
        data.nonce = import_page.nonce; // add nonce to data

        $.ajax({
            url: import_page.ajax_url,
            type: 'POST',
            data: data,
        }).then(function (response) {
            if (response.success) {
                // $('#export-messages').append(response.message);
                alert(response.message);
                return;
            }
            alert('Export failed!');

        }).catch(function (error) {
            console.log(error);
            alert('Export failed!');
        });
    });
    jQuery(document).ready(function ($) {
        $('#export_widget_form').on('submit', function (e) {
            e.preventDefault();

            let nonce = import_page.nonce;

            $.ajax({
                url: import_page.ajax_url,
                type: 'POST',
                data: {
                    action: 'export_widgets',
                    nonce: nonce
                },
            }).then(function (response) {
                console.log(response);
                if (response.success) {
                    alert('Export widgets successfully!');

                    let link = document.createElement('a');
                    link.href = response.download_url;
                    link.download = 'widgets.json';
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                } else {
                    alert('' + (response.message || ''));
                }
            }).catch(function (error) {
                console.error('Lỗi AJAX:', error);
                alert('');
            });
        });
    });

    $('#export_option_form').on('submit', function (e) {
        e.preventDefault();

        let nonce = import_page.nonce;

        $.ajax({
            url: import_page.ajax_url,
            type: 'POST',
            data: {
                action: 'export_options',
                nonce: nonce
            },
        }).then(function (response) {
            console.log(response);

            if (response.success) {
                alert('Export Theme Options successfully!');

                let link = document.createElement('a');
                link.href = '/wp-content/uploads/theme_option.ser';
                link.download = 'theme_option.ser';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            } else {
                alert(' ' + (response.message || ''));
            }
        }).catch(function (error) {
            console.error('', error);
            alert('');
        });
    });

    $('#export_setting_form').on('submit', function (e) {
        e.preventDefault();

        let nonce = import_page.nonce;

        $.ajax({
            url: import_page.ajax_url,
            type: 'POST',
            data: {
                action: 'export_settings',
                nonce: nonce
            },
        }).then(function (response) {
            console.log(response);

            if (response.success) {
                alert('Export Settings successfully!');


                let link = document.createElement('a');
                link.href = response.download_url;
                link.download = 'settings.json';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            } else {
                alert(' ' + (response.message || ''));
            }
        }).catch(function (error) {
            console.error('', error);
            alert('');
        });
    });

    // verify purchase code
    $("#theme_verify_form").on("submit", (e) => {
        e.preventDefault();
        var envato_name = $('input[name="user_envato_name"]').val();
        var user_purchase_code = $('input[name="user_purchase_code"]').val();
        var seft = $(this);
        seft.find('button.check-verify').append('<i class="fa fa-spinner fa-spin"></i>').attr('disabled', 'disabled');
        $.ajax({
        type: "POST",
        url: ajaxurl,
        crossDomain: true,
        data: {
          action: "purchase_code_verify",
          envato_name: envato_name,
          user_purchase_code: user_purchase_code,
        },
        success: function (data) {
          $("#check-result").html(data);
          if ($(".vr-message.message-success").length > 0)
            $("#message").fadeOut();
          else $("#message").fadeIn();
          seft.find("i").remove();
          seft.find('button.check-verify').removeAttr('disabled');
          setTimeout(function () {
            location.reload();
          }, 2000);
        },
        error: function (MLHttpRequest, textStatus, errorThrown) {
          console.log(errorThrown);
          alert('Please try again later');
          seft.find('button.check-verify').removeAttr('disabled');
        },
      });
    });

});